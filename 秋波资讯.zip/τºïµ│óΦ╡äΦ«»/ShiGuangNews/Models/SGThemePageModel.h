//
//  SGThemePageModel.h
//  NewsReader
//
//  Created by Davin on 15/10/15.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import "SGBaseReaderModel.h"

@interface SGThemePageModel : SGBaseReaderModel

//文章的标题
@property (nonatomic, copy) NSString *title;
//标题的配图
@property (nonatomic, strong) NSArray *images;
//文章的id
@property (nonatomic, copy) NSString *themeID;
//内容网址
@property (nonatomic, copy) NSString *share_url;
//标题高度
@property (nonatomic, assign) CGFloat contentHeight;

@end
