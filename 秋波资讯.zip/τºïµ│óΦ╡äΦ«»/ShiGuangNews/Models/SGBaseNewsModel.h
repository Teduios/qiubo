//
//  BaseNewsModel.h
//  BearNews
//
//  Created by Davin on 15/10/15.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SGBaseNewsModel : NSObject


@end
