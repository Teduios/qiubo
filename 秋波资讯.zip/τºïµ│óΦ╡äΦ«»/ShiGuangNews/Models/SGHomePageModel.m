//
//  SGHomePageModel.m
//  NewsReader
//
//  Created by Davin on 15/10/15.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import "SGHomePageModel.h"


@implementation SGHomePageModel
//id不能直接声明,所以用homeID代替
- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    if ([key isEqualToString:@"id"]) {
        self.homeID = [value stringValue];
    }
    if ([key isEqualToString:@"date"]) {
        self.homeDate = [value stringValue];
    }
}

- (CGFloat)contentHeight {
    CGRect rect = [self.title boundingRectWithSize:CGSizeMake(kTitleWidthMax, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:@{NSFontAttributeName : [UIFont systemFontOfSize:15]} context:nil];
    return rect.size.height;
}

@end
