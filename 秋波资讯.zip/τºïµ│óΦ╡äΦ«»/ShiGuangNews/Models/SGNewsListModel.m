//
//  NewsListModel.m
//  BearNews
//
//  Created by Davin on 15/10/15.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import "SGNewsListModel.h"

@implementation SGNewsListModel


- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    if ([key isEqualToString:@"id"]) {
        self.identifier = value;
    }
}

@end
