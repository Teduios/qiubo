//
//  NewsListModel.h
//  BearNews
//
//  Created by Davin on 15/10/15.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import "SGBaseNewsModel.h"

@interface SGNewsListModel : SGBaseNewsModel

@property(copy, nonatomic) NSString *identifier;//新闻id
@property(strong, nonatomic) NSNumber *comments;//评论次数
@property(copy, nonatomic) NSString *uinname;//新闻分类
@property(copy, nonatomic) NSString *commentid;//评论页id
@property(copy, nonatomic) NSString *title;//新闻标题
@property(copy, nonatomic) NSString *url;//新闻链接
@property(copy, nonatomic) NSString *articletype;//新闻展示类型
@property(strong, nonatomic) NSNumber *imagecount;//新闻内图片数量;
@property(strong, nonatomic) NSArray *thumbnails_qqnews;//新闻单元格图片
@property(copy, nonatomic) NSString *abstract;//新闻副标题


@end
