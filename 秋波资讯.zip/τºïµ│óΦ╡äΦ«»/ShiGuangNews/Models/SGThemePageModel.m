//
//  SGThemePageModel.m
//  NewsReader
//
//  Created by Davin on 15/10/15.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import "SGThemePageModel.h"

@implementation SGThemePageModel
//id不能直接声明,所以用themeID代替
- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    if ([key isEqualToString:@"id"]) {
        self.themeID = [value stringValue];
    }
}

- (CGFloat)contentHeight {
    CGRect rect = [self.title boundingRectWithSize:CGSizeMake(kTitleWidthMax, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:@{NSFontAttributeName : [UIFont systemFontOfSize:15]} context:nil];
    return rect.size.height;
}

@end
