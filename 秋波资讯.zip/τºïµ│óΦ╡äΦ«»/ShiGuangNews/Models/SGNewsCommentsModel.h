//
//  NewsCommentsModel.h
//  BearNews
//
//  Created by Davin on 15/10/15.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import "SGBaseNewsModel.h"

@interface SGNewsCommentsModel : SGBaseNewsModel

@property(copy, nonatomic) NSString *commentid;//评论页id
@property(copy, nonatomic) NSString *reply_content;//评论内容;
@property(copy, nonatomic) NSString *nick;//昵称
@property(copy, nonatomic) NSString *head_url;//头像链接地址
@property(copy, nonatomic) NSString *mb_nick_name;//手机客户端昵称
@property(copy, nonatomic) NSString *mb_head_url;//手机客户端头像链接
@property(copy, nonatomic) NSString *char_name;//昵称拼音
@end
