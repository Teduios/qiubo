//
//  SGMainTabBarInstance.h
//  秋波资讯
//
//  Created by Bean on 15/11/19.
//  Copyright © 2015年 蓝鸥科技. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SGMainTabBarInstance : NSObject
+ (id)sharedInstance;
@end
