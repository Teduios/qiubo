//
//  SGMainTabBarInstance.m
//  秋波资讯
//
//  Created by Bean on 15/11/19.
//  Copyright © 2015年 逗乐科技. All rights reserved.
//

#import "SGMainTabBarInstance.h"
#import "SGMainTabBarController.h"
static SGMainTabBarController *obj = nil;
@implementation SGMainTabBarInstance

+ (id)sharedInstance{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        obj = [SGMainTabBarController new];
    });
    
    return obj;
}
@end
