//
//  Global.h
//  ShiGuangNews
//
//  Created by Davin on 15/10/15.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//




// App强制重新加载的时间间隔
#define APP_FORCE_LAUNCH                60 * 60

// 主界面强制刷新的时间间隔
#define MAIN_FORCE_REFRESH              30 * 60

// 数据缓存更新的时间间隔
#define CORE_DATA_EXPIRED_TIME          8 * 60 * 60

// 系统容许的最大缓存(M)
#define CACHE_SIZE_CORDON               50


//阅读界面相关宏定义
/*
 **文章列表的宽高设置
 */

#define kLeftSpacing 10 //标题距离左边距的宽度
#define kTopSpacing 10   //标题距离上边距的高度
#define kRowHeight 100  //文章列表单元格的高度
#define kTitleLabelWidth  SCREEN_WIDTH - 3 * kLeftSpacing - kTitleImageViewWidth //标题的宽度
#define kTitleLabelHeight  kRowHeight - 2 * kTopSpacing  //标题的高度
#define kTitleImageViewWidth 125 //标题配图的宽度
#define kTitleImageViewHeight kRowHeight - 2 * kTopSpacing //标题配图的高度

/*
 ** 视图控制器
 */
#define CONTROLLER_WIDTH self.view.bounds.size.width
#define CONTROLLER_HEIGHT self.view.bounds.size.height


/*
 **菜单按钮控制器
 */



#define RADIUS 130.0        //菜单圆盘的半径
#define PICTURENUM 6       //按钮的个数

#define STARTTAG 1000       //第一个按钮的tag值
#define TIME 1.0         //动画的时长
#define SCALENUMBER 1.25      //形变比例
#define MENUWidth 100        //按钮的宽度
#define MENUHeight 100      //按钮的高度


/*
 **高度自适应
 */
#define kTitleWidthMax 200   //标题高度自适应宽度的值

//一天的时间
#define DAYTIME 60 * 60 * 24

//最大float值
#define MAXFLOAT    0x1.fffffep+127f

