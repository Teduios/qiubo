//
//  Macro.h
//  NewTest
//
//  Created by leipu on 15/10/11.
//  Copyright (c) 2015年 Leo. All rights reserved.
//

#pragma mark - UI & FILE

/* 检测，是否运行在iOS7.0或更高版本 */
#ifndef NSFoundationVersionNumber_iOS_6_1
#define NSFoundationVersionNumber_iOS_6_1  993.00
#endif
#define MINIMAL_UI (NSFoundationVersionNumber > NSFoundationVersionNumber_iOS_6_1)

/* 检查设备类型 */
#define IPAD (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)

/* 控件高度 */
#define NAVIGATION_BAR_HEIGHT               (MINIMAL_UI ? 64.0f : 44.0f)
#define STATUS_BAR_HEIGHT                   20      // 状态栏
#define TOOLBAR_HEIGHT                      44      // 底部工具栏
#define TABBAR_HEIGHT                       (MINIMAL_UI ? 49.0f : 44.0f)


#define SCREEN_WIDTH ([UIScreen mainScreen].bounds.size.width)      // 屏幕宽度
#define SCREEN_HEIGHT ([UIScreen mainScreen].bounds.size.height)    // 屏幕高度
#define SCREEN_SCALE ([UIScreen mainScreen].scale)


#define isIos7      ([[[UIDevice currentDevice] systemVersion] floatValue])
#define StatusbarSize ((isIos7 >= 7 && __IPHONE_OS_VERSION_MAX_ALLOWED > __IPHONE_6_1)?20.f:0.f)

// 通过Red, Green, Blue设置颜色值
#define UIColorWithRGBA(r,g,b,a)    [UIColor colorWithRed:(r)/255.0f green:(g)/255.0f blue:(b)/255.0f alpha:(a)]
#define UIColorWithRGB(r,g,b)       UIColorWithRGBA(r, g, b, 1.0)

// 通过16进制数设置颜色值
#define UIColorWithHexA(rgbValue,a) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 \
green:((float)((rgbValue & 0xFF00) >> 8))/255.0 \
blue:((float)(rgbValue & 0xFF))/255.0 \
alpha:(a)]
#define UIColorWithHex(rgbValue)    UIColorWithHexA(rgbValue, 1.0)

// 通过图片设置颜色值
#define UIColorWithTexture(image) [UIColor colorWithPatternImage:[UIImage imageNamed:image]]


#pragma mark - Path

#define kHomePath           NSHomeDirectory()
#define kCachePath          [NSHomeDirectory() stringByAppendingPathComponent:@"Library/Caches"]
#define kDocumentFolder     [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0]
#define kDocumentFolder2    [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"]
#define kLibraryPath        [NSHomeDirectory() stringByAppendingPathComponent:@"Library"]
#define kTempPath           NSTemporaryDirectory()
#define kMainBoundPath      [[NSBundle mainBundle] bundlePath]
#define kResourcePath       [[NSBundle mainBundle] resourcePath]
#define kExecutablePath     [[NSBundle mainBundle] executablePath]

#pragma mark - System

#define IOS_VERSION         [[[UIDevice currentDevice] systemVersion] floatValue]
#define APP_VERSION         [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"]
#define BUNDLE_NAME         [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleName"]
#define BUNDLE_VERSION      [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleVersion"]
#define BUNDLE_ID           [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleIdentifier"]

#define iPhone5 ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(640, 1136), [[UIScreen mainScreen] currentMode].size) : NO)

#define iPhone6 ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(750, 1334), [[UIScreen mainScreen] currentMode].size) : NO)

#define iPhone6Plus ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1242, 2208), [[UIScreen mainScreen] currentMode].size) : NO)

#pragma mark - Number

#define DEGREES_TO_RADIANS(x) (M_PI * (x) / 180.0) // 弧度转角度
#define RADIANS_TO_DEGREES(x) (r * 180.0) / (M_PI)  // 角度转弧度

#pragma mark - Log

#ifdef DEBUG
#   define DLog(...) NSLog((@"%s [Line %d] %@"), __PRETTY_FUNCTION__, __LINE__, [NSString stringWithFormat:__VA_ARGS__])
#   define SLog(...) NSLog(__VA_ARGS__)

#else
#   define DLog(...)
#   define SLog(...)
#endif

#pragma mark - String

#define HSStringFromCGSize(size) [NSString stringWithFormat:@"%.0f_%.0f", size.width * SCREEN_SCALE, size.height * SCREEN_SCALE]

#define EXCEPT_STATUS_BAR_HEIGHT (NAVIGATION_BAR_HEIGHT - STATUS_BAR_HEIGHT)

