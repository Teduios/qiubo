//
//  API.h
//  BearNews
//
//  Created by Davin on 15/10/15.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//



//某个种类新闻的所有新闻id及钱20条新闻的接口
#define GFirstRequestHTTP @"http://r.inews.qq.com/getQQNewsIndexAndItems?"
//上拉加载新闻接口
#define GRefreshListHTTP @"http://r.inews.qq.com/getQQNewsListItems?"
//评论页接口
#define GCommentListHTTP @"http://r.inews.qq.com/getQQNewsComment?"
//新闻详情页接口
#define GNewsDetailHTTP @"http://r.inews.qq.com/getSimpleNews/"

//阅读base接口
#define kBaseReaderURL @"http://news-at.zhihu.com/api/4"
//主题专栏接口,需要拼接专栏的id,获得数据
#define kThemeListURL @"/theme/"
//首页接口
#define kHomePageURL @"/stories/"
//当天数据接口
#define kLatestURL @"latest?"
//首页中间拼接接口
#define kBeforeURL @"before/"
//内容详情接口,需要拼接文章的id,获得数据
#define kContentURL @"/story/"