//
//  NSMutableArray+ConfigureDatasource.h
//  BearNews
//
//  Created by Davin on 15/10/15.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface NSMutableArray (ConfigureDatasource)


- (NSMutableArray *)configureDatasource:(NSString *)URLString tableView:(UITableView *)tableView;
- (void)requestNewsWithURLString:(NSString *)URLString tableView:(UITableView *)tableView comments:(NSMutableArray *)commentsArray;
@end
