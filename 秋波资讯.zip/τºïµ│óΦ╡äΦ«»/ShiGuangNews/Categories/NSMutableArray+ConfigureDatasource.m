//
//  NSMutableArray+ConfigureDatasource.m
//  BearNews
//
//  Created by Davin on 15/10/15.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import "NSMutableArray+ConfigureDatasource.h"
#import "AFNetworking.h"
#import "SGNewsListModel.h"
#import <QuartzCore/QuartzCore.h>


@implementation NSMutableArray (ConfigureDatasource)


- (NSMutableArray *)configureDatasource:(NSString *)URLString tableView:(UITableView *)tableView
{
    NSMutableArray *datasource = [NSMutableArray array];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager GET:URLString parameters:nil success:^(AFHTTPRequestOperation * operation, id responseObject) {
        NSArray *idlistArray = responseObject[@"idlist"];
        NSDictionary *rootDict = idlistArray[0];
        NSArray *idsArray = rootDict[@"ids"];
        NSArray *newslistArray = rootDict[@"newslist"];
        for (NSDictionary *dict in idsArray) {
            SGNewsListModel *model = [[SGNewsListModel alloc] init];
            [model setValuesForKeysWithDictionary:dict];
            [self addObject:model];
        }
        NSInteger index = 0;
        for (NSDictionary *dict in newslistArray) {
            SGNewsListModel *model = [self objectAtIndex:index];
            [model setValuesForKeysWithDictionary:dict];
            [datasource addObject:model];
            index++;
        }
        [tableView reloadData];
        [tableView.header endRefreshing];
    } failure:^(AFHTTPRequestOperation * operation, NSError * error) {
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 2*SCREEN_WIDTH / 3, 120)];
        label.center = tableView.center;
        label.textAlignment = NSTextAlignmentCenter;
        label.text = @"无法连接到网络";
        label.textColor = [UIColor whiteColor];
        label.font = [UIFont systemFontOfSize:23];
        label.adjustsFontSizeToFitWidth = YES;
        label.backgroundColor = [UIColor blackColor];
        label.layer.cornerRadius = 20;
        label.layer.masksToBounds = YES;
        label.alpha = 0.25;
        label.tag = 1100;
        [tableView addSubview:label];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            UIView *label = [tableView viewWithTag:1100];
            [label removeFromSuperview];
            [tableView.header endRefreshing];
        });
        DLog(@"%@",error);
    }];
    return datasource;
}

- (void)requestNewsWithURLString:(NSString *)URLString tableView:(UITableView *)tableView comments:(NSMutableArray *)commentsArray
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager GET:URLString parameters:nil success:^(AFHTTPRequestOperation * operation, id responseObject) {
        NSArray *newslistArray = responseObject[@"newslist"];
        NSInteger index = 0;
        for (NSDictionary *dict in newslistArray) {
            SGNewsListModel *model = [[SGNewsListModel alloc] init];
            [model setValuesForKeysWithDictionary:dict];
            model.comments = commentsArray[index];
            [self addObject:model];
            index++;
        }
        [tableView reloadData];
    } failure:^(AFHTTPRequestOperation * operation, NSError * error) {
        DLog(@"%@",error);
    }];
}

@end
