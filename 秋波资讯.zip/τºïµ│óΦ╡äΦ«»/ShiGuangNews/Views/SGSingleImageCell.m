//
//  SGSingleImageCell.m
//  ShiGuangNews
//
//  Created by Davin on 15/10/15.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import "SGSingleImageCell.h"

#define IMAGE_HEIGHT SCREEN_WIDTH * 0.515

@implementation SGSingleImageCell

@synthesize titleLabel = _titleLabel, newsImageView = _newsImageView;

- (UIImageView *)newsImageView
{
    if (!_newsImageView) {
        self.newsImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, IMAGE_HEIGHT)];
        [self.contentView insertSubview:_newsImageView atIndex:0];
        UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"backgroudImage"]];
        imageView.frame = _newsImageView.bounds;
        [_newsImageView addSubview:imageView];
    }
    return _newsImageView;
}

- (UILabel *)titleLabel
{
    if (!_titleLabel) {
        self.titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, IMAGE_HEIGHT *0.8, SCREEN_WIDTH - 30, 30)];
        _titleLabel.font = [UIFont systemFontOfSize:20];
        _titleLabel.adjustsFontSizeToFitWidth = YES;
        _titleLabel.textAlignment = NSTextAlignmentCenter;
        _titleLabel.textColor = [UIColor whiteColor];
        [self.contentView addSubview:_titleLabel];
    }
    return _titleLabel;
}



/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
