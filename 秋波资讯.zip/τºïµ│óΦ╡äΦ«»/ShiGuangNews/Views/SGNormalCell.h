//
//  BaseTableViewCell.h
//  ShiGuangNews
//
//  Created by Davin on 15/10/15.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SGNormalCell : UITableViewCell

@property(strong, nonatomic) UILabel *titleLabel;//标题
@property(strong, nonatomic) UILabel *summary;//新闻概要
@property(strong, nonatomic) UIImageView *newsImageView;//图片
@property(strong, nonatomic) UILabel *commentlabel;//评论

@end
