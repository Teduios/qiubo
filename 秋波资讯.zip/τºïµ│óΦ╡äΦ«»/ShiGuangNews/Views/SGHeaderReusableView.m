//
//  HeaderReusableView.m
//  ShiGuangNews
//
//  Created by Davin on 15/10/15.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import "SGHeaderReusableView.h"

@implementation SGHeaderReusableView

- (UILabel *)titlelabel
{
    if (!_titlelabel) {
        self.titlelabel = [[UILabel alloc] initWithFrame:self.bounds];
        _titlelabel.textColor = UIColorWithHex(0x238BFF);
        _titlelabel.font = [UIFont systemFontOfSize:20];
        _titlelabel.textAlignment = NSTextAlignmentCenter;
        [self addSubview:_titlelabel];
    }
    return _titlelabel;
}
@end
