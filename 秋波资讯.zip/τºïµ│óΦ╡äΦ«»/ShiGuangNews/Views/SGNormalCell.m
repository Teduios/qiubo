//
//  BaseTableViewCell.m
//  ShiGuangNews
//
//  Created by Davin on 15/10/15.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import "SGNormalCell.h"

#define IMAGE_WIDTH SCREEN_WIDTH * 0.2
#define IMAGE_HEIGHT SCREEN_WIDTH * 0.16
#define COMMENT_WIDTH 55
#define COMMENT_HEIGHT 20
@implementation SGNormalCell


- (UIImageView *)newsImageView
{
    if (!_newsImageView) {
        self.newsImageView = [[UIImageView alloc] initWithFrame:CGRectMake(15, 10, SCREEN_WIDTH * 0.2, SCREEN_WIDTH * 0.16)];
        [self.contentView addSubview:_newsImageView];
    }
    return _newsImageView;
}

- (UILabel *)titleLabel
{
    if (!_titleLabel) {
        self.titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(IMAGE_WIDTH + 25, 9, SCREEN_WIDTH - (IMAGE_WIDTH + 40), IMAGE_HEIGHT / 3)];
        _titleLabel.font = [UIFont systemFontOfSize:18];
        _titleLabel.adjustsFontSizeToFitWidth = YES;
        [self.contentView addSubview:_titleLabel];
    }
    return _titleLabel;
}

- (UILabel *)summary
{
    if (!_summary) {
        self.summary = [[UILabel alloc] initWithFrame:CGRectMake(IMAGE_WIDTH + 25, 9 + IMAGE_HEIGHT / 3, SCREEN_WIDTH - (IMAGE_WIDTH + 40), IMAGE_HEIGHT * 2 / 3)];
        _summary.font = [UIFont systemFontOfSize:IMAGE_HEIGHT / 4];
        _summary.textColor = [UIColor grayColor];
        _summary.numberOfLines = 0;
        [self.contentView addSubview:_summary];
    }
    return _summary;
}

- (UILabel *)commentlabel
{
    if (!_commentlabel) {
        self.commentlabel = [[UILabel alloc] initWithFrame:CGRectMake(SCREEN_WIDTH - COMMENT_WIDTH - 15, IMAGE_HEIGHT * 2 / 3 + 10, COMMENT_WIDTH, COMMENT_HEIGHT)];
        _commentlabel.font = [UIFont systemFontOfSize:IMAGE_HEIGHT / 4];
        _commentlabel.textColor = [UIColor grayColor];
        _commentlabel.textAlignment = NSTextAlignmentRight;
        [self.contentView addSubview:_commentlabel];
    }
    return _commentlabel;
}
@end
