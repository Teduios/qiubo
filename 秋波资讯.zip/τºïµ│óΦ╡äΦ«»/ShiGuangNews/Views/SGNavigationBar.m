//
//  NavigationBar.m
//  ShiGuangNews
//
//  Created by Davin on 15/10/15.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import "SGNavigationBar.h"
#import "SGNewsTypeModel.h"

#define LABEL_HEIGHT EXCEPT_STATUS_BAR_HEIGHT
#define LABEL_WIDTH ((SCREEN_WIDTH - EXCEPT_STATUS_BAR_HEIGHT * 2) / 5)
@interface SGNavigationBar ()<UIScrollViewDelegate>
@property(assign, nonatomic) NSInteger previousIndex;
@end

@implementation SGNavigationBar

- (UIButton *)leftButton
{
    if (!_leftButton) {
        self.leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _leftButton.frame = CGRectMake(0, STATUS_BAR_HEIGHT , EXCEPT_STATUS_BAR_HEIGHT, EXCEPT_STATUS_BAR_HEIGHT );
        [self insertSubview:_leftButton atIndex:3];
    }
    return _leftButton;
}

- (UIButton *)rightButton
{
    if (!_rightButton) {
        self.rightButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _rightButton.frame = CGRectMake(SCREEN_WIDTH - EXCEPT_STATUS_BAR_HEIGHT, STATUS_BAR_HEIGHT, EXCEPT_STATUS_BAR_HEIGHT, EXCEPT_STATUS_BAR_HEIGHT);
        [self insertSubview:_rightButton atIndex:3];
    }
    return _rightButton;
}

- (UIImageView *)backgroundImage
{
    if (!_backgroundImage) {
        self.backgroundImage = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH,NAVIGATION_BAR_HEIGHT)];
        [self insertSubview:_backgroundImage atIndex:0];
    }
    return _backgroundImage;
}

- (UILabel *)title
{
    if (!_title) {
        self.title = [[UILabel alloc] initWithFrame:CGRectMake(EXCEPT_STATUS_BAR_HEIGHT * 2, STATUS_BAR_HEIGHT, SCREEN_WIDTH - EXCEPT_STATUS_BAR_HEIGHT * 4,EXCEPT_STATUS_BAR_HEIGHT)];
        _title.textAlignment = NSTextAlignmentCenter;
        _title.font = [UIFont systemFontOfSize:20];
        _title.textColor = UIColorWithHex(0x238BFF);
        [self insertSubview:_title atIndex:1];
    }
    return _title;
}

- (UIView *)titleView
{
    if (!_titleView) {
        self.titleView = [[UIView alloc] initWithFrame:CGRectMake(EXCEPT_STATUS_BAR_HEIGHT, STATUS_BAR_HEIGHT, SCREEN_WIDTH - EXCEPT_STATUS_BAR_HEIGHT * 2,EXCEPT_STATUS_BAR_HEIGHT)];
        [self insertSubview:_titleView atIndex:2];
    }
    return _titleView;
}



- (UIButton *)backButton
{
    if (!_backButton) {
        self.backButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _backButton.frame = CGRectMake(0, STATUS_BAR_HEIGHT , EXCEPT_STATUS_BAR_HEIGHT, EXCEPT_STATUS_BAR_HEIGHT );
        [_backButton setImage:[UIImage imageNamed:@"titlebar_btn_back"]  forState:UIControlStateNormal];
        [_backButton setImageEdgeInsets:UIEdgeInsetsMake(10, 10, 10, 10)];
        [self insertSubview:_backButton atIndex:3];
    }
    return _backButton;
}

- (void)setScrollTitleWithTitleArray:(NSArray *)titleArray
{
    self.scrollTitle = [[UIScrollView alloc] initWithFrame:CGRectZero];
    self.scrollTitle.showsHorizontalScrollIndicator = NO;
    self.scrollTitle.delegate = self;
    [self.titleView addSubview:_scrollTitle];
    
    if (titleArray.count < 5 && titleArray.count != 0) {
        self.scrollTitle.frame = CGRectMake(0, 0, LABEL_WIDTH * titleArray.count, 44);
    }else
    {
        self.scrollTitle.frame = CGRectMake(0, 0, LABEL_WIDTH * 5, 44);
    }
    for (int i = 0; i < titleArray.count; i++) {
        self.scrollTitle.contentSize = CGSizeMake(LABEL_WIDTH * (i + 1), STATUS_BAR_HEIGHT);
        self.scrollTitle.center = CGPointMake(CGRectGetWidth(self.titleView.bounds) / 2,EXCEPT_STATUS_BAR_HEIGHT / 2);
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(LABEL_WIDTH * i, 0,LABEL_WIDTH, LABEL_HEIGHT)];
        SGNewsTypeModel *model = titleArray[i];
        label.text = model.title;
        if (i == 0) {
            label.textColor = UIColorWithHex(0x238BFF);
            label.font = [UIFont systemFontOfSize:20];
            self.previousIndex = 1000;
        }else
        {
            label.textColor = [UIColor grayColor];
            label.font = [UIFont systemFontOfSize:16];
        }
        label.textAlignment = NSTextAlignmentCenter;
        label.tag = 1000 + i;
        label.userInteractionEnabled = YES;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTap:)];
        [label addGestureRecognizer:tap];
        [self.scrollTitle addSubview:label];
    }
}

- (void)handleTap:(UITapGestureRecognizer *)sender
{
    UILabel *previousLabel = (UILabel *)[self viewWithTag:self.previousIndex];
    previousLabel.textColor = [UIColor grayColor];
    previousLabel.font = [UIFont systemFontOfSize:16];
    UILabel *currentLabel = (UILabel *)sender.view;
    currentLabel.textColor = UIColorWithHex(0x238BFF);
    currentLabel.font = [UIFont systemFontOfSize:20];
    self.previousIndex = currentLabel.tag;
    [self.delegate replaceNewsPage:currentLabel.tag - 1000];
}

- (void)refreshNewsPage
{
    CGFloat showMin = self.scrollTitle.contentOffset.x / LABEL_WIDTH;
    CGFloat showMax = showMin + 4;
    if (self.currentIndex < showMin) {
        self.scrollTitle.contentOffset = CGPointMake(self.currentIndex * LABEL_WIDTH, 0);
    }else if (self.currentIndex > showMax)
    {
        self.scrollTitle.contentOffset = CGPointMake((self.currentIndex - 4) * LABEL_WIDTH, 0);
    }
    [self refreshTitle];
    
}

- (void)refreshTitle
{
    UILabel *previousLabel = (UILabel *)[self viewWithTag:self.previousIndex];
    previousLabel.textColor = [UIColor grayColor];
    previousLabel.font = [UIFont systemFontOfSize:16];
    UILabel *currentLabel = (UILabel *)[self viewWithTag:self.currentIndex + 1000];
    currentLabel.textColor = UIColorWithHex(0x238BFF);
    currentLabel.font = [UIFont systemFontOfSize:20];
    self.previousIndex = currentLabel.tag;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
