//
//  NavigationBar.h
//  ShiGuangNews
//
//  Created by Davin on 15/10/15.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SGNavigationBar;

@protocol SGNavigationBarDelegate <NSObject>

- (void)replaceNewsPage:(NSInteger)page;

@end

@interface SGNavigationBar : UIView

@property(strong, nonatomic) UIButton *leftButton;//左边按钮
@property(strong, nonatomic) UILabel *title;//标题
@property(strong, nonatomic) UIImageView *backgroundImage;//背景图片
@property(strong, nonatomic) UIButton *backButton;//返回按钮;
@property(strong, nonatomic) UIButton *rightButton;//右边按钮
@property(strong, nonatomic) UIView *titleView;//自定义标题视图;
@property(strong, nonatomic) UIScrollView *scrollTitle;//滚动标题
@property(assign, nonatomic) NSInteger currentIndex;//当前页面所处位置的下标
@property(weak, nonatomic) id<SGNavigationBarDelegate>delegate;//代理
- (void)setScrollTitleWithTitleArray:(NSArray *)titleArray;
- (void)refreshNewsPage;

@end

