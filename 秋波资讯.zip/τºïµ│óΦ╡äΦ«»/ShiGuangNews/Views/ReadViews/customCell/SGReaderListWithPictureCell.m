//
//  SGReaderListWithPictureCell.m
//  NewsReader
//
//  Created by Davin on 15/10/16.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import "SGReaderListWithPictureCell.h"


@implementation SGReaderListWithPictureCell

//初始化
//懒加载
//显示标题
- (UILabel *)SGTitleLabel {
    if (!_SGTitleLabel) {
        self.SGTitleLabel = [[UILabel alloc] initWithFrame:CGRectMake(kLeftSpacing, kTopSpacing, kTitleLabelWidth, kTitleLabelHeight)];
        //设置字体颜色
        _SGTitleLabel.textColor = [UIColor blackColor];
        //设置字体大小
        _SGTitleLabel.font = [UIFont systemFontOfSize:15];
        //设置标题行数
        _SGTitleLabel.numberOfLines = 0;
        [self.contentView addSubview:_SGTitleLabel];
    }
    return _SGTitleLabel;
}

//显示标题
- (UIImageView *)SGTitleImageView {
    if (!_SGTitleImageView) {
        self.SGTitleImageView = [[UIImageView alloc] initWithFrame:CGRectMake(2 * kLeftSpacing + kTitleLabelWidth, kTopSpacing, kTitleImageViewWidth, kTitleImageViewHeight)];
        _SGTitleImageView.contentMode = UIViewContentModeScaleAspectFill;
        _SGTitleImageView.clipsToBounds = YES;
        [self.contentView addSubview:_SGTitleImageView];
    }
    return _SGTitleImageView;
}

- (void)configureCellWithModel:(SGHomePageModel *)model {
    //加载标题
    self.SGTitleLabel.text = model.title;
    //加载图片
    [self.SGTitleImageView sd_setImageWithURL:[NSURL URLWithString:model.images[0]]];
    //标题高度自适应
    CGRect contentFrame = self.SGTitleLabel.frame;
    contentFrame.size.height = model.contentHeight;
    self.SGTitleLabel.frame = contentFrame;
}

- (void)configureCellWithModels:(SGThemePageModel *)model {
    //加载标题
    self.SGTitleLabel.text = model.title;
    //加载图片
    [self.SGTitleImageView sd_setImageWithURL:[NSURL URLWithString:model.images[0]]];
    //标题高度自适应
    CGRect contentFrame = self.SGTitleLabel.frame;
    contentFrame.size.height = model.contentHeight;
    self.SGTitleLabel.frame = contentFrame;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
