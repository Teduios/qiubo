//
//  SGReaderListWithPictureCell.h
//  NewsReader
//
//  Created by Davin on 15/10/16.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import "SGBaseReaderListCell.h"
#import "SGHomePageModel.h"
#import "SGThemePageModel.h"


@interface SGReaderListWithPictureCell : SGBaseReaderListCell
//文章列表的标题
@property (nonatomic, strong) UILabel *SGTitleLabel;
//文章列表的标题旁边的配图
@property (nonatomic, strong) UIImageView *SGTitleImageView;

- (void)configureCellWithModel:(SGHomePageModel *)model;  //配置首页内容列表

- (void)configureCellWithModels:(SGThemePageModel *)model;  //配置专栏内容列表

@end
