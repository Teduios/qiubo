//
//  SGReadNavigationBar.m
//  ShiGuangNews
//
//  Created by Davin on 15/10/23.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import "SGReadNavigationBar.h"

@implementation SGReadNavigationBar

- (UIImageView *)backgroundImage
{
    if (!_backgroundImage) {
        self.backgroundImage = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH,NAVIGATION_BAR_HEIGHT)];
        [self insertSubview:_backgroundImage atIndex:0];
    }
    return _backgroundImage;
}

- (UILabel *)title
{
    if (!_title) {
        self.title = [[UILabel alloc] initWithFrame:CGRectMake(EXCEPT_STATUS_BAR_HEIGHT, 30, SCREEN_WIDTH - 2 * EXCEPT_STATUS_BAR_HEIGHT, NAVIGATION_BAR_HEIGHT - 20 - 2 * 10)];
        _title.textAlignment = NSTextAlignmentCenter;
        _title.textColor = [UIColor blackColor];
        [self insertSubview:_title atIndex:1];
    }
    return _title;
}

- (UIButton *)backButton
{
    if (!_backButton) {
        self.backButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _backButton.frame = CGRectMake(0, STATUS_BAR_HEIGHT , EXCEPT_STATUS_BAR_HEIGHT, EXCEPT_STATUS_BAR_HEIGHT );
        [_backButton setImage:[UIImage imageNamed:@"titlebar_btn_back"]  forState:UIControlStateNormal];
        [_backButton setImage:[UIImage imageNamed:@"titlebar_btn_back_press"] forState:UIControlStateHighlighted];
        [_backButton addTarget:self action:@selector(backButtonDidClicked:) forControlEvents:UIControlEventTouchDown];
        [self insertSubview:_backButton atIndex:2];
    }
    return _backButton;
}

- (void)backButtonDidClicked:(UIButton *)backButton {
    if (self.delegate && [self.delegate respondsToSelector:@selector(clickedBackButton:)]) {
        [self.delegate clickedBackButton:backButton];
    }
}



@end
