//
//  MenuItemView.h
//  Menu
//
//  Created by Davin on 15/10/23.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//



#import <UIKit/UIKit.h>

@protocol MenuItemViewDelegate <NSObject>

- (void)didTappedAction:(NSInteger)index;

@end

@interface MenuItemView : UIButton
//创建代理对象
@property (nonatomic, assign)id<MenuItemViewDelegate>menuDelegate;
//自定义初始化方法
- (instancetype)initWithNormalImage:(NSString *)normalImage highlightedImage:(NSString *)hightlightedImage menuTag:(NSInteger)menuTag menuTitle:(NSString *)menuTitle;

@end
