//
//  MenuItemView.m
//  Menu
//
//  Created by Davin on 15/10/23.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import "MenuItemView.h"

@interface MenuItemView ()
//正常状态的图片
@property(nonatomic, copy) NSString *normalImage;
//选中状态的图片
@property(nonatomic, copy) NSString *hightlightedImage;
//tag值
@property(nonatomic, assign) NSInteger menuTag;
//设置按钮的标题
@property(nonatomic, copy) NSString *menuTitle;

@end

@implementation MenuItemView

#pragma mark - init
//初始化
- (instancetype)initWithNormalImage:(NSString *)normalImage highlightedImage:(NSString *)hightlightedImage menuTag:(NSInteger)menuTag menuTitle:(NSString *)menuTitle {
    self = [super init];
    if (self) {
        _normalImage = normalImage;
        _hightlightedImage = hightlightedImage;
        _menuTag = menuTag;
        _menuTitle = menuTitle;
        [self configViews];
    }
    return self;
}

#pragma mark - configViews
//配置
- (void)configViews {
    self.tag = _menuTag;
    [self setBackgroundImage:[UIImage imageNamed:_normalImage] forState:UIControlStateNormal];
    [self setImage:[UIImage imageNamed:_hightlightedImage] forState:UIControlStateHighlighted];
    [self addTarget:self action:@selector(handleMenuAction:) forControlEvents:UIControlEventTouchUpInside];
}

- (void)handleMenuAction:(UIButton *)sender {
    if (self.menuDelegate && [self.menuDelegate respondsToSelector:@selector(didTappedAction:)]) {
        [self.menuDelegate didTappedAction:sender.tag];
    }
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
