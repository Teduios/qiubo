//
//  SGReadNavigationBar.h
//  ShiGuangNews
//
//  Created by Davin on 15/10/23.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol customNavigationBarDelegate <NSObject>

- (void)clickedBackButton:(UIButton *)backButton;

@end

@interface SGReadNavigationBar : UIView

@property (nonatomic, strong) UILabel *title;  //标题
@property (nonatomic, strong) UIButton *backButton; //返回按钮
@property (nonatomic, strong) UIImageView *backgroundImage;  //背景图片
@property (nonatomic, assign) id<customNavigationBarDelegate>delegate; //设置代理对象

@end
