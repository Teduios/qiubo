//
//  SGMultiple.m
//  ShiGuangNews
//
//  Created by Davin on 15/10/15.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import "SGMultipleImageCell.h"

@implementation SGMultipleImageCell

@synthesize titleLabel = _titleLabel, newsImageView = _newsImageView, commentlabel = _commentlabel;

- (UILabel *)titleLabel
{
    if (!_titleLabel) {
        self.titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, 10, SCREEN_WIDTH - 30, 25)];
        _titleLabel.font = [UIFont systemFontOfSize:18];
        _titleLabel.adjustsFontSizeToFitWidth = YES;
        [self.contentView addSubview:_titleLabel];
    }
    return _titleLabel;
}

- (UIImageView *)newsImageView
{
    if (!_newsImageView) {
        self.newsImageView = [[UIImageView alloc] initWithFrame:CGRectMake(15, 45, SCREEN_WIDTH - 30, (SCREEN_WIDTH - 30) *0.24)];
        [self.contentView addSubview:_newsImageView];
    }
    return _newsImageView;
}

- (UILabel *)imageCount
{
    if (!_imageCount) {
        self.imageCount = [[UILabel alloc] initWithFrame:CGRectMake(SCREEN_WIDTH - 110, (SCREEN_WIDTH - 30) *0.24 + 50, 35, 17)];
        _imageCount.font = [UIFont systemFontOfSize:15];
        _imageCount.textColor = [UIColor grayColor];
        _imageCount.textAlignment = NSTextAlignmentRight;
        [self.contentView addSubview:_imageCount];
    }
    return _imageCount;
}

- (UILabel *)commentlabel
{
    if (!_commentlabel) {
        self.commentlabel = [[UILabel alloc] initWithFrame:CGRectMake(SCREEN_WIDTH - 65, (SCREEN_WIDTH - 30) *0.24 + 50, 50, 17)];
        _commentlabel.font = [UIFont systemFontOfSize:15];
        _commentlabel.textColor = [UIColor grayColor];
        _commentlabel.textAlignment = NSTextAlignmentRight;
        [self.contentView addSubview:_commentlabel];
    }
    return _commentlabel;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
