//
//  SGAttentionViewController.m
//  ShiGuangNews
//
//  Created by Davin on 15/10/15.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import "SGAttentionViewController.h"
#import "SGNewsTitleCell.h"
#import "SGNewsTypeModel.h"
#import "SGHeaderReusableView.h"
#import "UIScrollView+MJRefresh.h"

@interface SGAttentionViewController ()<UICollectionViewDataSource, UICollectionViewDelegate>

@property(strong, nonatomic) UICollectionView *collectionView;

@end

@implementation SGAttentionViewController


- (NSMutableArray *)datasource
{
    if (!_datasource) {
        self.datasource = [NSMutableArray array];
        SGNewsTypeModel *model = [[SGNewsTypeModel alloc] init];
        model.title = @"要闻";
        model.type = @"news_news_top";
        [_datasource addObject:model];
    }
    return _datasource;
}

- (UICollectionView *)collectionView
{
    if (!_collectionView) {
        UICollectionViewFlowLayout * flowLayout = [[UICollectionViewFlowLayout alloc] init];
        flowLayout.minimumInteritemSpacing = 15;
        flowLayout.minimumInteritemSpacing = 15;
        flowLayout.itemSize = CGSizeMake((SCREEN_WIDTH - 60) / 3, 35);
        flowLayout.sectionInset = UIEdgeInsetsMake(20, 15, 20, 15);
        flowLayout.headerReferenceSize = CGSizeMake(SCREEN_WIDTH, 30);
        self.collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, NAVIGATION_BAR_HEIGHT, SCREEN_WIDTH, SCREEN_HEIGHT) collectionViewLayout:flowLayout];
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
        _collectionView.backgroundColor =UIColorWithRGB(246, 246, 246);
        [self.view addSubview:_collectionView];
    }
    return _collectionView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self.naviBar.backButton addTarget:self action:@selector(handleBackBt:) forControlEvents:UIControlEventTouchUpInside];
    self.naviBar.title.text = @"添加关注";
    NSString *path = [[NSBundle mainBundle] pathForResource:@"NewsTypeList" ofType:@"plist"];
    NSMutableArray *newsArray = [NSMutableArray arrayWithContentsOfFile:path];
    NSMutableArray *array = [NSMutableArray array];
    for (NSDictionary *dict in newsArray) {
        SGNewsTypeModel *model = [[SGNewsTypeModel alloc] init];
        model.title = dict.allKeys[0];
        model.type = dict[model.title];
        [array addObject:model];
    }
    self.allTitle = array;
    [self.collectionView registerClass:[SGNewsTitleCell class] forCellWithReuseIdentifier:@"CELL"];
    [self.collectionView registerClass:[SGHeaderReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"Header"];
}

- (void)handleBackBt:(UIButton *)sender
{
    [self.navigationController popToRootViewControllerAnimated:YES];
    self.passNews(self.datasource,self.allTitle);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 2;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    if (section == 1) {
       return self.allTitle.count;
    }
    return self.datasource.count;
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        SGHeaderReusableView *reusable = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"Header" forIndexPath:indexPath];
        reusable.titlelabel.text = @"已关注新闻";
        return reusable;
    }
    SGHeaderReusableView *reusable = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"Header" forIndexPath:indexPath];
    reusable.titlelabel.text = @"可添加新闻";
    return reusable;
}


- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    SGNewsTitleCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"CELL" forIndexPath:indexPath];
    if (indexPath.section == 0) {
        SGNewsTypeModel *model = self.datasource[indexPath.item];
        cell.title.text = model.title;
        if (indexPath.item == 0) {
            cell.title.textColor = [UIColor grayColor];
            cell.userInteractionEnabled = NO;
        }else{
            
        }
    }else
    {
        SGNewsTypeModel *model = self.allTitle[indexPath.item];
        cell.title.text = model.title;
    }
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
        if (indexPath.section == 0) {
            NSInteger number = [collectionView numberOfItemsInSection:1];
            NSInteger count = [collectionView numberOfItemsInSection:0];
            if (count > 2) {
                [self.allTitle addObject:self.datasource[indexPath.item]];
                NSIndexPath *index = [NSIndexPath indexPathForItem:number inSection:1];
                [collectionView insertItemsAtIndexPaths:@[index]];
                [collectionView reloadItemsAtIndexPaths:@[index]];
                [self.datasource removeObjectAtIndex:indexPath.item];
                [collectionView deleteItemsAtIndexPaths:@[indexPath]];
            }
        }else
        {
            NSInteger number = [collectionView numberOfItemsInSection:0];
            [self.datasource addObject:self.allTitle[indexPath.item]];
            NSIndexPath *index = [NSIndexPath indexPathForItem:number inSection:0];
            [collectionView insertItemsAtIndexPaths:@[index]];
            [collectionView reloadItemsAtIndexPaths:@[index]];
            [self.allTitle removeObjectAtIndex:indexPath.item];
            [collectionView deleteItemsAtIndexPaths:@[indexPath]];
        }
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
