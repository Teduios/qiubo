//
//  FirstViewController.m
//  ShiGuangNews
//
//  Created by Davin on 15/10/15.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import "SGNewsListViewController.h"
#import "MJRefresh.h"
#import "NSMutableArray+ConfigureDatasource.h"
#import "SGNewsListModel.h"
#import "UIImageView+WebCache.h"
#import "SGDetailViewController.h"
@interface SGNewsListViewController ()<UITableViewDataSource, UITableViewDelegate>

@property (strong, nonatomic) UITableView *tableView;

@property(strong, nonatomic) NSMutableArray *allNews;//保存所有新闻的id;
@property(strong, nonatomic) NSMutableArray *datasource;//数据源
@property(assign, nonatomic) NSInteger nextNewsIndex;//当前最后一条新闻下标
@property(strong, nonatomic) NSString *newsChild;//子新闻名称

@end

@implementation SGNewsListViewController

#pragma  mark - 懒加载

- (UITableView *)tableView
{
    if (!_tableView) {
        self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT - NAVIGATION_BAR_HEIGHT - TABBAR_HEIGHT) style:UITableViewStylePlain];
        [self.view addSubview:_tableView];
    }
    return _tableView;
}



- (NSMutableArray *)allNews
{
    if (!_allNews) {
        self.allNews = [NSMutableArray array];
    }
    return _allNews;
}

- (NSMutableArray *)datasource
{
    if (!_datasource) {
        self.datasource = [NSMutableArray array];
    }
    return _datasource;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


- (void)refreshPage
{
    [self.tableView registerClass:[SGNormalCell class] forCellReuseIdentifier:@"NORMAL"];
    [self.tableView registerClass:[SGSingleImageCell class] forCellReuseIdentifier:@"SINGLE"];
    [self.tableView registerClass:[SGMultipleImageCell class] forCellReuseIdentifier:@"MULTIPLE"];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.separatorInset = UIEdgeInsetsMake(0, 15, 0, 15);
    self.newsChild = [self.newsDelegate configureDatasource:self];
    NSString *URLString = [NSString stringWithFormat:@"%@chlid=%@",GFirstRequestHTTP,self.newsChild];
    //下拉刷新
    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.datasource removeAllObjects];
        [self.tableView.footer resetNoMoreData];
        self.datasource = [self.allNews configureDatasource:URLString tableView:self.tableView];
        self.nextNewsIndex = 20;
//        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//            // 结束刷新
//            [self.tableView.header endRefreshing];
//        });
    }];
    [self.tableView.header beginRefreshing];
    //上拉加载
    self.tableView.footer = [MJRefreshAutoNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(requestNews)];
}

#pragma mark - UItableViewDelegate&Datasource

//设置tableView分区数量
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.datasource.count;
}

//设置行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.datasource.count > 0) {
        SGNewsListModel *model = self.datasource[indexPath.row];
        if (indexPath.row == 0) {
            return SCREEN_WIDTH * 0.515;
        }else if ([model.articletype isEqualToString:@"1"])
        {
            return (SCREEN_WIDTH - 30) *0.24 + 77;
        }
    }
    return SCREEN_WIDTH * 0.16 + 20;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.datasource.count > 0) {
        SGNewsListModel *model = self.datasource[indexPath.row];
        if (indexPath.row == 0) {
            SGSingleImageCell *cell = [tableView dequeueReusableCellWithIdentifier:@"SINGLE" forIndexPath:indexPath];
            cell.backgroundColor = UIColorWithRGB(246, 246, 246);
            [self configureSingleImageCell:cell atIndexPath:indexPath];
            return cell;
        }else if ([model.articletype isEqualToString:@"1"])
        {
            SGMultipleImageCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MULTIPLE" forIndexPath:indexPath];
            [self configureMultipleImageCell:cell atIndexPath:indexPath];
            cell.backgroundColor = UIColorWithRGB(246, 246, 246);
            return cell;
        }
    }
    SGNormalCell *cell = [tableView dequeueReusableCellWithIdentifier:@"NORMAL" forIndexPath:indexPath];
    [self configureNormalCell:cell atIndexPath:indexPath];
    cell.backgroundColor = UIColorWithRGB(246, 246, 246);
    return cell;
}


#pragma mark - 配置不同单元单元格

//配置
- (void)configureNormalCell:(SGNormalCell *)cell atIndexPath:(NSIndexPath *)indexPath
{
    if (self.datasource.count > 0) {
        SGNewsListModel *model = self.datasource[indexPath.row];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.titleLabel.text = model.title;
        cell.summary.text = model.abstract;
        [cell.newsImageView sd_setImageWithURL:[NSURL URLWithString:model.thumbnails_qqnews[0]]];
        CGFloat comments = [model.comments doubleValue];
        if (comments > 9999.0f) {
            NSString *commentSting = [NSString stringWithFormat:@"%.1f万评",comments/10000.0f];
            if ([commentSting containsString:@".0"]) {
                cell.commentlabel.text = [NSString stringWithFormat:@"%.f万评",comments/10000.0f];
            }else
            {
                cell.commentlabel.text = commentSting;
            }
        }else
        {
            cell.commentlabel.text = [NSString stringWithFormat:@"%.f评",comments];
        }
    }
}

- (void)configureSingleImageCell:(SGSingleImageCell *)cell atIndexPath:(NSIndexPath *)indexPath
{
    SGNewsListModel *model = self.datasource[indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.titleLabel.text = model.title;
    [cell.newsImageView sd_setImageWithURL:[NSURL URLWithString:model.thumbnails_qqnews[0]]];
}

- (void)configureMultipleImageCell:(SGMultipleImageCell *)cell atIndexPath:(NSIndexPath *)indexPath
{
    SGNewsListModel *model = self.datasource[indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.titleLabel.text = model.title;
    cell.imageCount.text = [NSString stringWithFormat:@"%@图",model.imagecount];
    [cell.newsImageView sd_setImageWithURL:[NSURL URLWithString:model.thumbnails_qqnews[0]]];
    CGFloat comments = [model.comments doubleValue];
    if (comments > 9999.0f) {
        
        cell.commentlabel.text = [NSString stringWithFormat:@"%.1f万评",comments/10000.0f];
        
    }else
    {
        cell.commentlabel.text = [NSString stringWithFormat:@"%.f评",comments];
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    SGDetailViewController *detailVC = [[SGDetailViewController alloc] init];
    SGNewsListModel *model = self.datasource[indexPath.row];
    detailVC.detailURL = model.url;
    [self.navigationController pushViewController:detailVC animated:YES];
}


#pragma mark - 上拉加载数据

- (void)requestNews
{
    if (self.nextNewsIndex < 200) {
        NSMutableArray *newsArray = [NSMutableArray array];
        NSMutableArray *commentsArray = [NSMutableArray array];
        for (NSInteger i = self.nextNewsIndex; i < self.nextNewsIndex + 20; i++) {
            [newsArray addObject:[self.allNews[i] identifier]];
            [commentsArray addObject:[self.allNews[i] comments]];
        }
        NSString *newsString = [@"ids=" stringByAppendingString:[newsArray componentsJoinedByString:@"%2C"]];
        NSString *URLString = [NSString stringWithFormat:@"%@%@&%@",GRefreshListHTTP,newsString,self.newsChild];
        [self.datasource requestNewsWithURLString: URLString tableView:self.tableView comments:commentsArray];
        [self.tableView.footer endRefreshing];
        self.nextNewsIndex += 20;
    }else
    {
        //加载完毕所有数据
        [self.tableView.footer noticeNoMoreData];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
