//
//  SGAttentionViewController.h
//  ShiGuangNews
//
//  Created by Davin on 15/10/15.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import "SGNaviViewController.h"

typedef  void (^passValue)(NSMutableArray *,NSMutableArray *);

@interface SGAttentionViewController : SGNaviViewController
@property(strong, nonatomic) NSMutableArray *datasource;
@property(strong, nonatomic) NSMutableArray *allTitle;
@property(copy, nonatomic) passValue passNews;
@end
