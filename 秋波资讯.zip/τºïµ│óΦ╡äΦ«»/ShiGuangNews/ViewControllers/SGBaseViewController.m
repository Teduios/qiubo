//
//  SGBaseViewController.m
//  ShiGuangNews
//
//  Created by Davin on 15/10/21.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import "SGBaseViewController.h"

#import "SGLoginViewController.h"
#import "SGLoginModel.h"

@interface SGBaseViewController ()



@end

@implementation SGBaseViewController

- (SGNavigationBar *)naviBar
{
    if (!_naviBar) {
        self.naviBar = [[SGNavigationBar alloc] initWithFrame:CGRectMake(0, 0,SCREEN_WIDTH, NAVIGATION_BAR_HEIGHT)];
        [self.view addSubview:_naviBar];
    }
    return _naviBar;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //自定义导航栏
    self.naviBar = [[SGNavigationBar alloc]initWithFrame:CGRectMake( 0, 0, SCREEN_HEIGHT, NAVIGATION_BAR_HEIGHT)];
    self.naviBar.backgroundColor = [UIColor whiteColor];
    self.naviBar.backgroundImage.image = [UIImage imageNamed:@"navigation_bar_top.9"];
    [self.naviBar.leftButton setImage:[UIImage imageNamed:@"iconfont-back"] forState:UIControlStateNormal];
    [self.naviBar.leftButton setImageEdgeInsets:UIEdgeInsetsMake(10, 10, 10, 10)];
    [self.naviBar.leftButton addTarget:self action:@selector(backAction:) forControlEvents:UIControlEventTouchDown];
    [self.view addSubview:self.naviBar];
}



-(void)backAction:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
