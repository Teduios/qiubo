//
//  LoginViewController.m
//  ShiGuangNews
//
//  Created by Davin on 15/10/15.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import "SGLoginViewController.h"
#import "SDWebImageManager.h"
#import "SGLoginModel.h"
#import "SGNavigationBar.h"
#import "SGMainViewController.h"
#import "SGMainTabBarController.h"
#import "SGMainTabBarInstance.h"

@interface SGLoginViewController ()<UITableViewDataSource, UITableViewDelegate,UIAlertViewDelegate,UIWebViewDelegate>
@property (nonatomic, strong) SGMainTabBarController *contentTabVC;
@property (nonatomic, strong) NSMutableArray *datasource;
@property (nonatomic, assign) CGFloat tmpSize;
@property (nonatomic, strong) UITableView *loginTableView;


@end

@implementation SGLoginViewController

- (SGMainTabBarController *)contentTabVC {
    if(_contentTabVC == nil) {
        _contentTabVC = [SGMainTabBarInstance sharedInstance];
    }
    return _contentTabVC;
}

- (UITableView *)loginTableView
{
    if (!_loginTableView) {
        self.loginTableView = [[UITableView alloc]initWithFrame:self.view.bounds style:UITableViewStyleGrouped];
        self.naviBar.hidden = YES;//	隐藏导航栏
        self.loginTableView.dataSource = self;
        self.loginTableView.delegate = self;
        self.loginTableView.backgroundColor = [UIColor clearColor];
    }
    return _loginTableView;
}

- (NSMutableArray *)datasource
{
    if (!_datasource) {
        self.datasource = [NSMutableArray array];
    }
    return _datasource;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //login界面
    
    //背景加图,设置cell透明
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"daynight_back.png"]];
//    UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT*0.3)];
//    imageView.image = [UIImage imageNamed:@"beijingtu.jpg"];
    
//    [self.view addSubview:imageView];
    //隐藏分割线
//    [loginTable setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    
    self.loginTableView.tag = 1000;
//    self.loginTableView.scrollEnabled = NO;//禁止滑动
    self.loginTableView.frame = CGRectMake(0, 0, SCREEN_WIDTH*0.7, SCREEN_HEIGHT
                                  );
    self.loginTableView.mj_insetT = SCREEN_HEIGHT*0.10;
//    self.loginTableView.mj_insetB = SCREEN_HEIGHT*0.25;
    [self.loginTableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"CELL"];
    [self.view addSubview:self.loginTableView];
  
    //分区
    NSString *sourcePath = [[NSBundle mainBundle] pathForResource:@"CaiDan" ofType:@"plist"];
    NSArray *sourceArray = [NSArray arrayWithContentsOfFile:sourcePath];
    for (int i=0; i<sourceArray.count; i++) {
        NSMutableArray *array = [NSMutableArray array];
        [self.datasource addObject:array];
        NSArray *innerArray = sourceArray[i];
        for (NSDictionary *dict in innerArray) {
            SGLoginModel *model = [[SGLoginModel alloc]init];
            [model setValuesForKeysWithDictionary:dict];
            [array addObject:model];
        }
    }
}



#pragma mark -UITableViewDataSource 和 UITableViewDelegate 方法
//分区
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.datasource.count;
}
//行数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.datasource[section] count];
}

#pragma mark - cell方法
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CELL" forIndexPath:indexPath];
    SGLoginModel *model = [self.datasource[indexPath.section] objectAtIndex:indexPath.row];
    cell.imageView.image = [UIImage imageNamed:model.image];
    cell.imageView.layer.cornerRadius = 8;
    cell.imageView.layer.backgroundColor = [UIColor lightGrayColor].CGColor;
    cell.textLabel.text = model.title;
    cell.backgroundColor = [UIColor clearColor];//cell透明色
    cell.textLabel.textColor = [UIColor whiteColor];
    
    if (indexPath.section == 0||indexPath.section == 1 || indexPath.section == 2) {
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;//向右箭头
    }
    if (indexPath.section == 2) {
        if (indexPath.row == 0) {
            
            UILabel *Loginlabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 70, 40)];
            self.tmpSize = [[SDImageCache sharedImageCache] getSize]/1024.0/1024.0;//当前缓存数量
            Loginlabel.textAlignment = NSTextAlignmentRight;
            Loginlabel.backgroundColor = [UIColor clearColor];
            
            //            NSLog(@"%.2f",self.tmpSize);
            Loginlabel.text = [NSString stringWithFormat:@"%.1fMB",_tmpSize];
            Loginlabel.textColor = [UIColor whiteColor];
            //            Loginlabel.textColor = [UIColor darkGrayColor];
            cell.accessoryView = Loginlabel;
        }
    }
    return cell;
}



//单元格
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //    取消选择，过渡更自然
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
#pragma mark 回到资讯
    if (indexPath.section == 0 && indexPath.row == 0) {
        CGRect frame = self.contentTabVC.view.frame;
        frame.origin.x = 0;
        [UIView animateWithDuration:0.35 animations:^{
            self.contentTabVC.view.frame = frame;
        }completion:^(BOOL finished) {
            [self.view removeFromSuperview];
            self.view = nil;
        }];
    }
    
#pragma mark 游戏
    if (indexPath.section == 1 && indexPath.row == 0) {
        SGBaseViewController *SheZhi = [[SGBaseViewController alloc]init];
        [self.navigationController pushViewController:SheZhi animated:YES];
        
        UIWebView *webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, NAVIGATION_BAR_HEIGHT, SCREEN_WIDTH, SCREEN_HEIGHT)];
        NSURLRequest *requst=[NSURLRequest requestWithURL:[NSURL URLWithString:@"http://www.msgjug.com/p_life/page.html"]];
        webView.backgroundColor = [UIColor whiteColor];
        //自适应屏幕大小
        [webView setScalesPageToFit:YES];
        SheZhi.view.backgroundColor = [UIColor whiteColor];
        [SheZhi.view addSubview:webView];
        webView.delegate =self;
        [webView loadRequest:requst];
    }
#pragma mark 活动
    if (indexPath.section == 1 && indexPath.row == 1) {
        SGBaseViewController *CaiDan = [[SGBaseViewController alloc]init];
        [self.navigationController pushViewController:CaiDan animated:YES];
        
        UIWebView *webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, NAVIGATION_BAR_HEIGHT, SCREEN_WIDTH, SCREEN_HEIGHT)];
        NSURLRequest *requst=[NSURLRequest requestWithURL:[NSURL URLWithString:@"http://m.yxbao.com/mj/lolhuodong"]];
        webView.backgroundColor = [UIColor whiteColor];
        //自适应屏幕大小
        [webView setScalesPageToFit:YES];
        CaiDan.view.backgroundColor = [UIColor whiteColor];
        [CaiDan.view addSubview:webView];
        webView.delegate =self;
        [webView loadRequest:requst];
    }
#pragma 清理缓存图片
    if (indexPath.section == 2 && indexPath.row == 0) {
        //执行clearDisk和getSize清除缓存后reloadData实时更新数据-
        [[SDImageCache sharedImageCache] clearDisk];
        [[SDImageCache sharedImageCache] clearMemory];
        
        _tmpSize = [[SDImageCache sharedImageCache] getSize]/1024.0/1024.0;//当前缓存数量
        self.alert = [[UIAlertView alloc] initWithTitle:@"温馨提示" message:@"缓存清除成功" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        self.alert.delegate = self;
        [_alert show];
    }
#pragma mark 关于app
    if (indexPath.section == 3) {
        if (indexPath.row == 1) {
//            SGBaseViewController *CaiDan = [[SGBaseViewController alloc]init];
//            [self.navigationController pushViewController:CaiDan animated:YES];
//            UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, NAVIGATION_BAR_HEIGHT, SCREEN_WIDTH, SCREEN_HEIGHT-NAVIGATION_BAR_HEIGHT)];
//            imageView.backgroundColor = [UIColor colorWithRed:0 green:134/255.0 blue:219/255.0 alpha:1];
//            imageView.contentMode = UIViewContentModeScaleAspectFit;
//            imageView.image = [UIImage imageNamed:@"AboutUs.png"];
//            [CaiDan.view addSubview:imageView];
            
            SGBaseViewController *CaiDan = [[SGBaseViewController alloc]init];
            [self.navigationController pushViewController:CaiDan animated:YES];
            
            UIScrollView  *scrollView = [[UIScrollView alloc]init];
            scrollView.frame = CGRectMake(0, NAVIGATION_BAR_HEIGHT, SCREEN_WIDTH, SCREEN_HEIGHT);
            scrollView.backgroundColor = [UIColor blackColor];
            scrollView.contentSize = CGSizeMake(SCREEN_WIDTH, 700+64);
            //            scrollView.bounces = NO;//回弹动画
            [CaiDan.view addSubview:scrollView];
            UIImageView *imageView = [[UIImageView alloc]init];
            scrollView.backgroundColor = [UIColor whiteColor];
            imageView.image = [UIImage imageNamed:@"AboutUs.png"];
            imageView.frame = CGRectMake(0, 0, SCREEN_WIDTH, 700);
            [scrollView addSubview:imageView];
        }else{
            SGBaseViewController *CaiDan = [[SGBaseViewController alloc]init];
            [self.navigationController pushViewController:CaiDan animated:YES];
            
            UIScrollView  *scrollView = [[UIScrollView alloc]init];
            scrollView.frame = CGRectMake(0, NAVIGATION_BAR_HEIGHT, SCREEN_WIDTH, SCREEN_HEIGHT);
            scrollView.backgroundColor = [UIColor blackColor];
            scrollView.contentSize = CGSizeMake(SCREEN_WIDTH, 700+64);
            //            scrollView.bounces = NO;//回弹动画
            [CaiDan.view addSubview:scrollView];
            UIImageView *imageView = [[UIImageView alloc]init];
            scrollView.backgroundColor = [UIColor whiteColor];
            imageView.image = [UIImage imageNamed:@"decleration.png"];
            imageView.frame = CGRectMake(0, 0, SCREEN_WIDTH, 700);
            [scrollView addSubview:imageView];
        }
    }
}
#pragma mark -UIAlertView 刷新tableView
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    //缓存清除后,刷新label的显示
    [self.alert dismissWithClickedButtonIndex:0 animated:YES];
    UITableView *tableView = (UITableView *)[self.view viewWithTag:1000];
    [tableView reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/



@end
