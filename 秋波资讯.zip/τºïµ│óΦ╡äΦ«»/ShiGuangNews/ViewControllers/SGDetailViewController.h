//
//  SGDetailViewController.h
//  ShiGuangNews
//
//  Created by Davin on 15/10/15.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import "SGNaviViewController.h"

@interface SGDetailViewController : SGNaviViewController

@property(copy, nonatomic) NSString *detailURL;//新闻链接

@end
