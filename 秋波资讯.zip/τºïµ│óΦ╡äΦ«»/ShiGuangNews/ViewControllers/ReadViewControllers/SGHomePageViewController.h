//
//  SGHomePageViewController.h
//  NewsReader
//
//  Created by Davin on 15/10/16.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import "SGBaseReaderViewController.h"

@interface SGHomePageViewController : SGBaseReaderViewController

@property (nonatomic, strong) NSMutableArray *SGHomePageContent;//首页内容数据源
@property (nonatomic, strong) NSMutableArray *SGHomePageScroll; //轮播图的数据源

@end
