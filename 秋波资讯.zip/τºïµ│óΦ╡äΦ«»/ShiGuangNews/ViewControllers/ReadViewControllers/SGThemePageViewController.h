//
//  SGThemePageViewController.h
//  NewsReader
//
//  Created by Davin on 15/10/16.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import "SGBaseReaderViewController.h"

@interface SGThemePageViewController : SGBaseReaderViewController

@property (nonatomic, strong) NSMutableArray *SGThemePageDatasource;  //专栏内容数据源
@property (nonatomic, assign) NSNumber *themeCID;  //保存传过来的专栏id

@end
