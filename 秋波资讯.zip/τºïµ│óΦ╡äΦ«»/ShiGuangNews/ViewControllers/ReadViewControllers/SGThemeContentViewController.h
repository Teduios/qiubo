//
//  SGThemeContentViewController.h
//  NewsReader
//
//  Created by Davin on 15/10/16.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import "SGBaseReaderViewController.h"
#import "SGThemePageModel.h"

@interface SGThemeContentViewController : SGBaseReaderViewController

@property (nonatomic, copy) NSString *SGThemeShare;   //share_url中的值

@end
