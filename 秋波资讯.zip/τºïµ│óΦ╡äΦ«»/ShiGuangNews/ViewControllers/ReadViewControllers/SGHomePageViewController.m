//
//  SGHomePageViewController.m
//  NewsReader
//
//  Created by Davin on 15/10/16.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import "SGHomePageViewController.h"
#import "SGReaderListWithPictureCell.h"
#import "SGReaderListNoPictureCell.h"
#import "SGHomePageModel.h"
#import "SDCycleScrollView.h"
#import "SGHomeContentViewController.h"
#import "SGScrollContentViewController.h"
#import "SGReadNavigationBar.h"
#import "SGMenuViewController.h"

//SDCycleScrollViewDelegate
@interface SGHomePageViewController ()<UITableViewDataSource, UITableViewDelegate, SDCycleScrollViewDelegate, customNavigationBarDelegate>

@property (nonatomic, strong) SGReadNavigationBar *naviBar; //自定义单元格
@property (nonatomic, strong) UITableView *SGHomePageView;   //创建首页的tableView
@property (nonatomic, strong) NSMutableArray *SGHomePageContentArray;   //内容列表数据源
@property (nonatomic, strong) NSMutableArray *SGHomePageScrollArray;  //轮播图的数据源
@property (nonatomic, assign) NSInteger page;  //页数


@end

@implementation SGHomePageViewController

#pragma mark - init
//初始化
- (UITableView *)SGHomePageView {
    if (!_SGHomePageView) {
        self.SGHomePageView = [[UITableView alloc] initWithFrame:CGRectMake(0, TOOLBAR_HEIGHT, CONTROLLER_WIDTH, CONTROLLER_HEIGHT - 44) style:UITableViewStylePlain];
        _SGHomePageView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
        _SGHomePageView.separatorColor = [UIColor whiteColor];
        _SGHomePageView.delegate = self;
        _SGHomePageView.dataSource = self;
        [_SGHomePageView registerClass:[SGReaderListWithPictureCell class] forCellReuseIdentifier:@"PICCELL"];
        _SGHomePageView.rowHeight = kRowHeight;
        [self.view addSubview:_SGHomePageView];
    }
    return _SGHomePageView;
}

- (NSMutableArray *)SGHomePageContent {
    if (!_SGHomePageContent) {
        self.SGHomePageContent = [NSMutableArray array];
    }
    return _SGHomePageContent;
}

- (NSMutableArray *)SGHomePageContentArray {
    if (!_SGHomePageContentArray) {
        self.SGHomePageContentArray = [NSMutableArray array];
    }
    return _SGHomePageContentArray;
}

- (NSMutableArray *)SGHomePageScroll {
    if (!_SGHomePageScroll) {
        _SGHomePageScroll = [NSMutableArray array];
    }
    return _SGHomePageScroll;
}

- (NSMutableArray *)SGHomePageScrollArray {
    if (!_SGHomePageScrollArray) {
        _SGHomePageScrollArray = [NSMutableArray array];
    }
    return _SGHomePageScrollArray;
}

- (SGReadNavigationBar *)naviBar {
    if (!_naviBar) {
        _naviBar = [[SGReadNavigationBar alloc] initWithFrame:CGRectMake(0, 0,SCREEN_WIDTH, NAVIGATION_BAR_HEIGHT)];
        [_naviBar addSubview:_naviBar.backButton];
        [_naviBar addSubview:_naviBar.title];
        _naviBar.title.text = @"首页";
        _naviBar.backgroundImage.image = [UIImage imageNamed:@"navigation_bar_top.9"];
        _naviBar.delegate = self;
        [self.view addSubview:_naviBar];
    }
    return _naviBar;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //设置视图控制器的背景颜色,为了保证PUSH的时候不会有卡顿的状态
    self.view.backgroundColor = [UIColor whiteColor];
    _page = 1;
    for (NSMutableDictionary *dictionary in self.SGHomePageContent) {
        SGHomePageModel *model = [[SGHomePageModel alloc] init];
        [model setValuesForKeysWithDictionary:dictionary];
        [self.SGHomePageContentArray addObject:model];
    }
    [self.SGHomePageView reloadData];
    [self naviBar];
    [self scrollViewPicture];
    //开启刷新状态
    [self refreshHeader];
    [self refreshFooter];
}



#pragma mark - UITableViewDelegate & UITableViewDataSource


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.SGHomePageContentArray.count;
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    SGReaderListWithPictureCell *cell = [tableView dequeueReusableCellWithIdentifier:@"PICCELL" forIndexPath:indexPath];
    SGHomePageModel *model = self.SGHomePageContentArray[indexPath.row];
    //设置cell选中状态
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    //配置cell
    [cell configureCellWithModel:model];
    return cell;
}


//push入详情界面
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    dispatch_async(dispatch_get_global_queue( DISPATCH_QUEUE_PRIORITY_LOW, 0), ^{
        // Do something...
        MBProgressHUD *HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
        [self.navigationController.view addSubview:HUD];
        
        HUD.delegate = self;
        HUD.labelText = @"Loading";
        
        [HUD showWhileExecuting:@selector(myTask) onTarget:self withObject:nil animated:YES];
        dispatch_async(dispatch_get_main_queue(), ^{
            [MBProgressHUD hideHUDForView:self.view animated:YES];
        });
    });
    SGHomePageModel *model = self.SGHomePageContentArray[indexPath.row];
    SGHomeContentViewController *SGHomeContentVC = [[SGHomeContentViewController alloc] init];
    NSString *URL = [NSString stringWithFormat:@"%@%@%@",kBaseReaderURL,kContentURL,model.homeID];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager GET:URL parameters:nil success:^(AFHTTPRequestOperation * operation, id responseObject) {
        SGHomeContentVC.SGHomeShare = [responseObject objectForKey:@"share_url"];
        [self.navigationController pushViewController: SGHomeContentVC animated:YES];
    } failure:^(AFHTTPRequestOperation * operation, NSError * error) {
        DLog(@"%@",error);
    }];
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    NSDate *date = [NSDate date];
    //设置时间的格式
    [formatter setTimeZone:[NSTimeZone timeZoneWithName:@"Asia/Hong_Kong"]];
    [formatter setDateFormat:@"yyyy年MM月dd日  生命不息,阅读不止"];
    //将日期转换为字符串
    NSString *time = [formatter stringFromDate:date];
    return time;
}

#pragma mark - 下拉刷新,上拉加载
//下拉刷新
- (void)refreshHeader {
    // 设置回调（一旦进入刷新状态，就调用target的action，也就是调用self的loadNewData方法）
    MJRefreshNormalHeader *header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(parseNewData)];
    // 设置自动切换透明度(在导航栏下面自动隐藏)
    header.automaticallyChangeAlpha = YES;
    header.backgroundColor = [UIColor whiteColor];
    [header setTitle:@"Loading..." forState:MJRefreshStateRefreshing];
    // 隐藏时间
    header.lastUpdatedTimeLabel.hidden = YES;
    
    // 马上进入刷新状态
    [header beginRefreshing];
    
    // 设置header
    self.SGHomePageView.header = header;
}
//上拉加载
- (void)refreshFooter {
    // 添加默认的上拉刷新
    // 设置回调（一旦进入刷新状态，就调用target的action，也就是调用self的loadMoreData方法）
    MJRefreshAutoNormalFooter *footer = [MJRefreshAutoNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(parseMoreData)];
    
    // 设置文字
    [footer setTitle:@"Click or drag up to refresh" forState:MJRefreshStateIdle];
    [footer setTitle:@"Loading more ..." forState:MJRefreshStateRefreshing];
    [footer setTitle:@"No more data" forState:MJRefreshStateNoMoreData];
    
    // 设置字体
    footer.stateLabel.font = [UIFont systemFontOfSize:17];
    
    // 设置颜色
    footer.stateLabel.textColor = [UIColor blueColor];
    
    // 设置footer
    self.SGHomePageView.footer = footer;
}

- (void)parseNewData {
    if (_page == 1) {
        [_SGHomePageContentArray removeAllObjects];
        _page --;
    }
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    //重新请求数据
    NSString *hURL = [NSString stringWithFormat:@"%@%@%@",kBaseReaderURL,kHomePageURL,kLatestURL];
    [manager GET:hURL parameters:nil success:^(AFHTTPRequestOperation * operation, id responseObject) {
        //将数据写入缓存
        [self writeToFileWithHomeData:responseObject];
        NSArray *dataArray = [responseObject objectForKey:@"stories"];
        for (NSMutableDictionary *dictionary in dataArray) {
            SGHomePageModel *model = [[SGHomePageModel alloc] init];
            [model setValuesForKeysWithDictionary:dictionary];
            [self.SGHomePageContentArray addObject:model];
        }
        [self.SGHomePageView reloadData];
        // 拿到当前的下拉刷新控件，结束刷新状态
        [self.SGHomePageView.header endRefreshing];
    } failure:^(AFHTTPRequestOperation * operation, NSError * error) {
        DLog(@"%@",error);
    }];
}

- (void)parseMoreData {
    
    NSString *fURL = [NSString stringWithFormat:@"%@%@%@%@",kBaseReaderURL, kHomePageURL, kBeforeURL,[self setFrontDate]];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager GET:fURL parameters:nil success:^(AFHTTPRequestOperation * operation, id responseObject) {
        //将数据写入缓存
        [self writeToFileWithThemeData:responseObject];
        NSArray *dataArray = [responseObject objectForKey:@"stories"];
        for (NSMutableDictionary *dictionary in dataArray) {
            SGHomePageModel *model = [[SGHomePageModel alloc] init];
            [model setValuesForKeysWithDictionary:dictionary];
            [self.SGHomePageContentArray addObject:model];
        }
        [self setFrontDate];
        [self.SGHomePageView reloadData];
    } failure:^(AFHTTPRequestOperation * operation, NSError * error) {
        DLog(@"%@",error);
    }];
    
}
////获取网址后拼接的日期
- (NSString *)setFrontDate {
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    //从当天的日期开始加载一页减去一天
    NSDate *date = [[NSDate alloc] initWithTimeInterval:-DAYTIME * _page sinceDate:[NSDate date]];
    DLog(@"%@",date);
    //设置时间的格式
    [formatter setTimeZone:[NSTimeZone timeZoneWithName:@"Asia/Hong_Kong"]];
    [formatter setDateFormat:@"yyyyMMdd"];
    //将日期转换为字符串
    NSString *time = [formatter stringFromDate:date];
    //页数+1
    _page++;
    //回调上拉加载的方法
    [self refreshFooter];
    DLog(@"%@",time);
    return time;
    
}

//将数据写入缓存
#pragma mark - 缓存

- (void)writeToFileWithHomeData:(id)data
{
    //获取缓存路径
    NSArray *cachesPaths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *path = [cachesPaths objectAtIndex:0];
    DLog(@"%@",path);
    //创建文件名
    NSString *fileName = [path stringByAppendingString:@"SGHomePageView.json"];
    NSError *error= nil;
    //将请求的字符串写入缓存
    NSData *bdData = (NSData *)data;
    [bdData writeToFile:fileName atomically:YES];
    if (error) {
        DLog(@"******%@*******",[error localizedDescription]);
    }
    else
    {
        DLog(@"写入成功");
    }
}


//将数据写入缓存
- (void)writeToFileWithThemeData:(id)data
{
    //获取缓存路径
    NSArray *cachesPaths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *path = [cachesPaths objectAtIndex:0];
    //创建文件名
    NSString *fileName = [path stringByAppendingString:@"SGThemePageView.json"];
    NSError *error= nil;
    //将请求的字符串写入缓存
    NSData *bdData = (NSData *)data;
    [bdData writeToFile:fileName atomically:YES];
    if (error) {
        DLog(@"******%@*******",[error localizedDescription]);
    }
    else
    {
        DLog(@"写入成功");
    }
}

#pragma mark - 轮播图
- (void)scrollViewPicture {
    NSMutableArray *imageArray = [NSMutableArray array]; //轮播图图片
    NSMutableArray *titleArray = [NSMutableArray array]; //轮播图标题
    for (NSMutableDictionary * dictionary in _SGHomePageScroll) {
        SGHomePageModel *model = [[SGHomePageModel alloc] init];
        [model setValuesForKeysWithDictionary:dictionary];
        [imageArray addObject:model.image];
        [titleArray addObject:model.title];
        [self.SGHomePageScrollArray addObject:model];
    }
    //创建轮播图
    SDCycleScrollView *cycleScrollView = [SDCycleScrollView cycleScrollViewWithFrame:CGRectMake(0, 0, CONTROLLER_WIDTH, (CONTROLLER_WIDTH * 2) / 3) imagesGroup:nil];
    cycleScrollView.pageControlAliment = SDCycleScrollViewPageContolAlimentCenter;
    cycleScrollView.delegate = self;
    cycleScrollView.titlesGroup = titleArray;
    cycleScrollView.autoScrollTimeInterval = 5;
    cycleScrollView.titleLabelTextFont = [UIFont systemFontOfSize:17];
    [self.view addSubview:cycleScrollView];
    self.SGHomePageView.tableHeaderView = cycleScrollView;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        cycleScrollView.imageURLStringsGroup = imageArray;
    });
}



#pragma mark - SDCycleScrollViewDelegate
//push入详情界面
- (void)cycleScrollView:(SDCycleScrollView *)cycleScrollView didSelectItemAtIndex:(NSInteger)index {
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    dispatch_async(dispatch_get_global_queue( DISPATCH_QUEUE_PRIORITY_LOW, 0), ^{
        // Do something...
        MBProgressHUD *HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
        [self.navigationController.view addSubview:HUD];
        
        HUD.delegate = self;
        HUD.labelText = @"Loading";
        
        [HUD showWhileExecuting:@selector(myTask) onTarget:self withObject:nil animated:YES];
        dispatch_async(dispatch_get_main_queue(), ^{
            [MBProgressHUD hideHUDForView:self.view animated:YES];
        });
    });
    SGHomePageModel *model = self.SGHomePageScrollArray[index];
    DLog(@"%@",model);
    SGScrollContentViewController *SGScrollVC = [[SGScrollContentViewController alloc] init];
    NSString *URL = [NSString stringWithFormat:@"%@%@%@",kBaseReaderURL,kContentURL,model.homeID];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager GET:URL parameters:nil success:^(AFHTTPRequestOperation * operation, id responseObject) {
        SGScrollVC.SGScrollShare = [responseObject objectForKey:@"share_url"];
        [self.navigationController pushViewController: SGScrollVC animated:YES];
    } failure:^(AFHTTPRequestOperation * operation, NSError * error) {
        DLog(@"%@",error);
    }];
}

- (void)myTask {
    // Do something usefull in here instead of sleeping ...
    sleep(2);
}

#pragma mark - customNavigationBarDelegate
- (void)clickedBackButton:(UIButton *)backButton {
    [self.navigationController popViewControllerAnimated:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
