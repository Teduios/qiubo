//
//  SGMenuViewController.m
//  Menu
//
//  Created by Davin on 15/10/16.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import "SGMenuViewController.h"
#import "MenuItemView.h"
#import "SGHomePageViewController.h"
#import "SGThemePageViewController.h"
#import "SGReadNavigationBar.h"



NSInteger array [PICTURENUM][PICTURENUM] = {
    {0,1,2,3,4,5},
    {5,0,1,2,3,4},
    {4,5,0,1,2,3},
    {3,4,5,0,1,2},
    {2,3,4,5,0,1},
    {1,2,3,4,5,0}
};


@interface SGMenuViewController ()<MenuItemViewDelegate, MBProgressHUDDelegate, customNavigationBarDelegate>
//当前view的tag
@property (nonatomic, assign) NSInteger currentTag;
@property (nonatomic, strong) SGReadNavigationBar *naviBar; //自定义单元格
@property (nonatomic, strong) UIImageView *backIV;
@end

@implementation SGMenuViewController

CATransform3D rotationTransform_[PICTURENUM];

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"阅读" image:[[UIImage imageNamed:@"reader_normal_icon"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] selectedImage:[[UIImage imageNamed:@"reader_press_icon"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
        [self.tabBarItem setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:13]} forState:UIControlStateNormal];
    }
    return self;
}

- (SGReadNavigationBar *)naviBar {
    if (!_naviBar) {
        _naviBar = [[SGReadNavigationBar alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, NAVIGATION_BAR_HEIGHT)];
        _naviBar.backgroundImage.image = [UIImage imageNamed:@"navigation_bar_top.9"];
        _naviBar.delegate = self;
        [self.view addSubview:_naviBar];
    }
    return _naviBar;
}
- (UIImageView *)backIV {
    if(_backIV == nil) {
        _backIV = [[UIImageView alloc] init];
        _backIV.image = [UIImage imageNamed:@"backgroud2.png"];
        _backIV.userInteractionEnabled = YES;
        _backIV.frame =CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
        [self.view addSubview:_backIV];
    }
    return _backIV;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self configViews];
    [self naviBar];
    
}

#pragma mark - configViews

- (void)configViews {

    
    
    

    NSArray *dataArray = @[@"icon_main",@"icon_reference",@"icon_design",@"icon_company",@"icon_economic",@"icon_sport"];

    CGFloat center_y = self.view.center.y - 50;
    CGFloat center_x = self.view.center.x;
    for (NSInteger i = 0; i < PICTURENUM; i++) {
        CGFloat temp_y = center_y + RADIUS * cos(2.0 * M_PI * i / PICTURENUM);
        CGFloat temp_x = center_x - RADIUS * sin(2.0 * M_PI * i / PICTURENUM);
        MenuItemView *view = [[MenuItemView alloc] initWithNormalImage:dataArray[i] highlightedImage:[dataArray[i] stringByAppendingFormat:@"%@",@"_hover"] menuTag:STARTTAG + i menuTitle:nil];
        view.frame = CGRectMake(0, 0, MENUWidth, MENUHeight);
        //简单的示意,显示出按钮的样式,以后要添加图片
        view.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.0];
        view.center = CGPointMake(temp_x, temp_y);
        view.menuDelegate = self;
        rotationTransform_[i] = CATransform3DIdentity;
        //fabs(x)求浮点数x的绝对值,计算menu的形变比例
        CGFloat Scalenumber = fabs(i - PICTURENUM / 2.0) / (PICTURENUM / 2.0);
        if (Scalenumber < 0.3) {
            Scalenumber = 0.4;
        }
        //创建旋转形变
        CATransform3D rotationTransform = CATransform3DIdentity;
        //设置旋转形变的数值
        /*  CATransform3DScale (CATransform3D t, CGFloat sx,CGFloat sy, CGFloat sz)
         sx：X轴缩放，代表一个缩放比例，一般都是 0 --- 1 之间的数字。
         sy：Y轴缩放。
         sz：整体比例变换时，也就是m11（sx）== m22（sy）时，若m33（sz）>1，图形整体缩小，若0<1，图形整体放大，若m33（sz）<0，发生关于原点的对称等比变换。
         */
        rotationTransform = CATransform3DScale(rotationTransform, Scalenumber * SCALENUMBER, Scalenumber * SCALENUMBER, 1);
        //将menu的形变修改为创建的旋转形变
        view.layer.transform = rotationTransform;
        [self.backIV addSubview:view];
    }
    self.currentTag = STARTTAG;
    
}


#pragma mark - MenuItemViewDelegate

- (void)didTappedAction:(NSInteger)index {

    if (self.currentTag == index) {
        //如果触摸的是当前menu,创建动画push下一个视图
        CATransition *transition = [CATransition animation];
        transition.duration = 1.0f;
        transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
        transition.type = kCATransitionFade;
        transition.subtype = kCATransitionFromRight;
        transition.delegate = self;
        [self.navigationController.view.layer addAnimation:transition forKey:nil];
        if (index != STARTTAG) {
            [MBProgressHUD showHUDAddedTo:self.view animated:YES];
            dispatch_async(dispatch_get_global_queue( DISPATCH_QUEUE_PRIORITY_LOW, 0), ^{
                // Do something...
                MBProgressHUD *HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
                [self.navigationController.view addSubview:HUD];
                
                HUD.delegate = self;
                HUD.labelText = @"Loading";
                
                [HUD showWhileExecuting:@selector(myTask) onTarget:self withObject:nil animated:YES];
                dispatch_async(dispatch_get_main_queue(), ^{
                    [MBProgressHUD hideHUDForView:self.view animated:YES];
                });
            });
            SGThemePageViewController *SGThemeVC = [[SGThemePageViewController alloc] init];
            //将专题对应的ID放在一个数组中
            NSArray *themeID = @[@12,@4,@5,@6,@8];
            //保存专栏的id
            SGThemeVC.themeCID = themeID[index - 1000 - 1];
            DLog(@"%@",SGThemeVC.themeCID);
            //网络请求数据
            AFHTTPRequestOperationManager *themtManager = [AFHTTPRequestOperationManager manager];
            //拼接网络请求的借口地址
            NSString *themeURL = [NSString stringWithFormat:@"%@%@%@",kBaseReaderURL,kThemeListURL,themeID[index - 1000 - 1]];
            [themtManager GET:themeURL parameters:nil success:^(AFHTTPRequestOperation * operation, id responseObject) {
                SGThemeVC.SGThemePageDatasource = [responseObject objectForKey:@"stories"];
                DLog(@"SGT%@", SGThemeVC.SGThemePageDatasource);
                [self.navigationController pushViewController:SGThemeVC animated:YES];
            } failure:^(AFHTTPRequestOperation * operation, NSError * error) {
                DLog(@"%@",error);
                DXAlertView *alertView = [[DXAlertView alloc] initWithTitle:@"无  网  络" contentText:@"无WiFi, 不阅读" leftButtonTitle:nil rightButtonTitle:@"好   的"];
                [alertView show];
                alertView.rightBlock = ^() {
//                    NSLog(@"right button clicked");
                };
                alertView.dismissBlock = ^() {
//                    NSLog(@"Do something interesting after dismiss block");
                };
            }];
        }else {
            [MBProgressHUD showHUDAddedTo:self.view animated:YES];
            dispatch_async(dispatch_get_global_queue( DISPATCH_QUEUE_PRIORITY_LOW, 0), ^{
                // Do something...
                MBProgressHUD *HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
                [self.navigationController.view addSubview:HUD];
                
                HUD.delegate = self;
                HUD.labelText = @"Loading";
                
                [HUD showWhileExecuting:@selector(myTask) onTarget:self withObject:nil animated:YES];
                dispatch_async(dispatch_get_main_queue(), ^{
                    [MBProgressHUD hideHUDForView:self.view animated:YES];
                }); 
            });
            SGHomePageViewController *SGHomeVC = [[SGHomePageViewController alloc] init];
            //网络请求数据
            AFHTTPRequestOperationManager *homeManager = [AFHTTPRequestOperationManager manager];
            //拼接网络请求的借口地址
            NSString *homeURL = [NSString stringWithFormat:@"%@%@%@",kBaseReaderURL,kHomePageURL,kLatestURL];
            [homeManager GET:homeURL parameters:nil success:^(AFHTTPRequestOperation * operation, id responseObject) {
                //文章列表的数据源
                SGHomeVC.SGHomePageContent = [responseObject objectForKey:@"stories"];
                DLog(@"stro%@", SGHomeVC.SGHomePageContent);
                //轮播图的数据源
                SGHomeVC.SGHomePageScroll = [responseObject objectForKey:@"top_stories"];
                DLog(@"scroll:%@",SGHomeVC.SGHomePageScroll);
                [self.navigationController pushViewController:SGHomeVC animated:YES];
            } failure:^(AFHTTPRequestOperation * operation, NSError * error) {
                DLog(@"%@",error);
                DXAlertView *alertView = [[DXAlertView alloc] initWithTitle:@"无 网 络" contentText:@"无WiFi, 不阅读" leftButtonTitle:nil rightButtonTitle:@"好   的"];
                [alertView show];
                alertView.rightBlock = ^() {
//                    NSLog(@"right button clicked");
                };
                alertView.dismissBlock = ^() {
//                    NSLog(@"Do something interesting after dismiss block");
                };
            }];
        }
        return;
    }
    //获取下一个触摸的menu与当前menu的tag的差值
    NSInteger tapTag = [self getItemViewTag:index];
    DLog(@"%ld",(long)index);
    //获取对应tag的menu,为其添加动画
    for (NSInteger i = 0; i < PICTURENUM; i++) {
        UIView *view = [self.view viewWithTag:STARTTAG + i];
        [view.layer addAnimation:[self moveAnimation:STARTTAG + i number:tapTag] forKey:@"position"];
        [view.layer addAnimation:[self setScaleAnimation:STARTTAG + i clickTag:index] forKey:@"transform"];
        //计算其他menu的形变比例
        NSInteger j = array[index - STARTTAG][i];
        CGFloat Scalenumber = fabs(j - PICTURENUM / 2.0) / (PICTURENUM / 2.0);
        if (Scalenumber < 0.3) {
            Scalenumber = 0.4;
        }
    }
    self.currentTag = index;
}

- (void)myTask {
    // Do something usefull in here instead of sleeping ...
    sleep(1.5);
}

- (NSInteger)getItemViewTag:(NSInteger)tag {
    //判断当前menu的tag与要选择的menu的tag的值的大小,如果前者大,返回两个的差值,如果后者大,返回
    if (self.currentTag >tag){
        return self.currentTag  - tag;
    } else {
        return PICTURENUM  - tag + self.currentTag ;
    }
}

//菜单移动动画
- (CAAnimation *)moveAnimation:(NSInteger)tag number:(NSInteger)number {
    UIView *view = [self.view viewWithTag:tag];
    //创建关键帧动画,将旋转分为一段段的，组成路径，由CAKeyframeAnimation保存，每一段都由旋转的角度确定
    CAKeyframeAnimation *animation = [CAKeyframeAnimation animation];
    //创建可变的图形路径
    CGMutablePathRef path = CGPathCreateMutable();
    //CGPathMoveToPoint(CGMutablePathRef path,const CGAffineTransform *m, CGFloat x, CGFloat y)
    CGPathMoveToPoint(path, NULL, view.layer.position.x, view.layer.position.y);
    NSInteger pathTag = [self getItemViewTag:tag];
    CGFloat f = 2.0 * M_PI - 2.0 * M_PI * pathTag / PICTURENUM;
    CGFloat h = f + 2.0 * M_PI * number / PICTURENUM;
    CGFloat center_y = self.view.center.y - 50;
    CGFloat center_x = self.view.center.x;
    CGFloat temp_y = center_y + RADIUS * cos(h);
    CGFloat temp_x = center_x - RADIUS * sin(h);
    view.center = CGPointMake(temp_x, temp_y);
    //CGPathAddArc(CGMutablePathRef path, const CGAffineTransform *m,CGFloat x, CGFloat y, CGFloat radius, CGFloat startAngle, CGFloat endAngle,bool clockwise)
    //追加一个弧到可变路径中
    CGPathAddArc(path,nil,self.view.center.x, self.view.center.y - 50,RADIUS,f + M_PI / 2,f + M_PI / 2 + 2.0 * M_PI *number / PICTURENUM,0);
    animation.path = path;
    //递减保留图形路径的数
    CGPathRelease(path);
    animation.duration = TIME;
    animation.repeatCount = 1;
    animation.calculationMode = @"paced";
    return animation;
}

//按钮形变动画
- (CAAnimation *)setScaleAnimation:(NSInteger)tag clickTag:(NSInteger)clickTag {
    NSInteger iScale = array[clickTag - STARTTAG][tag - STARTTAG];
    NSInteger iScale1 = array[self.currentTag - STARTTAG][tag - STARTTAG];
    //形变比例
    CGFloat Scalenumber = fabs(iScale - PICTURENUM / 2.0) / (PICTURENUM / 2.0);
    CGFloat Scalenumber1 = fabs(iScale1 - PICTURENUM / 2.0) / (PICTURENUM / 2.0);
    if (Scalenumber < 0.3) {
        Scalenumber = 0.4;
    }
    //创建图层动画
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"transform"];
    animation.duration = TIME;
    animation.repeatCount = 1;
    CATransform3D dTemp = CATransform3DScale(rotationTransform_[tag - STARTTAG], Scalenumber * SCALENUMBER, Scalenumber * SCALENUMBER, 1);
    //设置动画的起始值
    animation.fromValue = [NSValue valueWithCATransform3D:CATransform3DScale(rotationTransform_[tag - STARTTAG], Scalenumber1 * SCALENUMBER, Scalenumber1 * SCALENUMBER, -1)];
    //设置动画的结束值
    animation.toValue = [NSValue valueWithCATransform3D:dTemp];
    animation.autoreverses = NO;
    animation.removedOnCompletion = NO;
    animation.fillMode = kCAFillModeForwards;
    return animation;
}

#pragma mark - customNavigationBarDelegate
- (void)clickedBackButton:(UIButton *)backButton {
    [self.navigationController popViewControllerAnimated:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */



@end
