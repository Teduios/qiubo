//
//  SGThemeContentViewController.m
//  NewsReader
//
//  Created by Davin on 15/10/16.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import "SGThemeContentViewController.h"
#import "SGReadNavigationBar.h"

@interface SGThemeContentViewController ()<UIWebViewDelegate, customNavigationBarDelegate>

@property (nonatomic, strong) SGReadNavigationBar *naviBar;  //自定义导航栏
@property (nonatomic, strong) UIWebView *SGThemeContentView;  //详情页
@property (nonatomic, strong) UIActivityIndicatorView *activityIndicatorView;  //加载动画

@end

@implementation SGThemeContentViewController

#pragma mark - init
//初始化
- (SGReadNavigationBar *)naviBar {
    if (!_naviBar) {
        _naviBar = [[SGReadNavigationBar alloc] initWithFrame:CGRectMake(0, 0,SCREEN_WIDTH, NAVIGATION_BAR_HEIGHT)];
        [_naviBar addSubview:_naviBar.backButton];
        _naviBar.backgroundImage.image = [UIImage imageNamed:@"navigation_bar_top.9"];
        _naviBar.delegate = self;
        [self.view addSubview:_naviBar];
    }
    return _naviBar;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    _SGThemeContentView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 44, SCREEN_WIDTH, SCREEN_HEIGHT-44)];
    _SGThemeContentView.scalesPageToFit = YES;  //自动对页面进行缩放以适应屏幕
    _SGThemeContentView.dataDetectorTypes = YES;//数据的类型转换为可点击的URL在Web视图的内容。
    _SGThemeContentView.delegate = self;
    NSURL *URL = [NSURL URLWithString:_SGThemeShare];
    DLog(@"%@",URL);
    NSURLRequest *request = [NSURLRequest requestWithURL:URL];
    [_SGThemeContentView loadRequest:request];
    [self.view addSubview:_SGThemeContentView];
    
    _activityIndicatorView = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(0, 0, 100, 100)];
    self.view.center = _activityIndicatorView.center;
    _activityIndicatorView.activityIndicatorViewStyle = UIActivityIndicatorViewStyleWhiteLarge;  //颜色根据不同的界面自己调整
    [self.view addSubview:_activityIndicatorView];
    [self naviBar];
}

#pragma mark - UIWebViewDelegate

//当网页视图已经开始加载一个请求之后得到通知

- (void) webViewDidStartLoad:(UIWebView  *)webView {
    [_activityIndicatorView startAnimating];
}

//当网页视图结束加载一个请求之后得到通知

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [_activityIndicatorView stopAnimating]; //停止风火轮
}

#pragma mark - customNavigationBarDelegate
- (void)clickedBackButton:(UIButton *)backButton {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
