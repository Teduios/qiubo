//
//  SGThemePageViewController.m
//  NewsReader
//
//  Created by Davin on 15/10/16.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import "SGThemePageViewController.h"
#import "SGReaderListWithPictureCell.h"
#import "SGReaderListNoPictureCell.h"
#import "SGThemeContentViewController.h"
#import "SGReadNavigationBar.h"

@interface SGThemePageViewController ()<UITableViewDataSource, UITableViewDelegate, customNavigationBarDelegate>

@property (nonatomic, strong) SGReadNavigationBar *naviBar; //自定义导航栏
@property (nonatomic, strong) NSMutableArray *SGThemePageContentArray;  //首页内容数据源
@property (nonatomic, strong) UITableView *SGThemePageView;   //创建UITableView
@property (nonatomic, assign) NSInteger page;  //页数

@end

@implementation SGThemePageViewController
//初始化
#pragma mark - init
//懒加载
- (UITableView *)SGThemePageView {
    if (!_SGThemePageView) {
        self.SGThemePageView = [[UITableView alloc] initWithFrame:CGRectMake(0, TOOLBAR_HEIGHT, CONTROLLER_WIDTH, CONTROLLER_HEIGHT - 44) style:UITableViewStylePlain];
        _SGThemePageView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
        _SGThemePageView.separatorColor = [UIColor lightGrayColor];
        _SGThemePageView.delegate = self;
        _SGThemePageView.dataSource = self;
        [_SGThemePageView registerClass:[SGReaderListWithPictureCell class] forCellReuseIdentifier:@"PICCELL"];
        [_SGThemePageView registerClass:[SGReaderListNoPictureCell class] forCellReuseIdentifier:@"NOPICCELL"];
        _SGThemePageView.rowHeight = kRowHeight;
        [self.view addSubview:_SGThemePageView];
    }
    return _SGThemePageView;
}

- (NSMutableArray *)SGThemePageDatasource {
    if (!_SGThemePageDatasource) {
        self.SGThemePageDatasource = [NSMutableArray array];
    }
    return _SGThemePageDatasource;
}


- (NSMutableArray *)SGThemePageContentArray {
    if (!_SGThemePageContentArray) {
        self.SGThemePageContentArray = [NSMutableArray array];
    }
    return _SGThemePageContentArray;
}

- (SGReadNavigationBar *)naviBar {
    if (!_naviBar) {
        _naviBar = [[SGReadNavigationBar alloc] initWithFrame:CGRectMake(0, 0,SCREEN_WIDTH, NAVIGATION_BAR_HEIGHT)];
        [_naviBar addSubview:_naviBar.backButton];
        [_naviBar addSubview:_naviBar.title];
        [self setNaviTitle];
        _naviBar.backgroundImage.image = [UIImage imageNamed:@"navigation_bar_top.9"];
        _naviBar.delegate = self;
        [self.view addSubview:_naviBar];
    }
    return _naviBar;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //设置视图控制器的背景颜色
    self.view.backgroundColor = [UIColor whiteColor];
    _page = 1;
    for (NSMutableDictionary *dictionary in self.SGThemePageDatasource) {
        SGThemePageModel *model = [[SGThemePageModel alloc] init];
        [model setValuesForKeysWithDictionary:dictionary];
        [self.SGThemePageContentArray addObject:model];
    }
    DLog(@"--%@",self.SGThemePageContentArray);
    [self.SGThemePageView reloadData];
    [self naviBar];
    [self refreshFooter];
}
//设置导航栏标题
- (void)setNaviTitle {
    NSArray *menuName = @[@"此处必有精品",@"分享设计的灵感和路径",@"高薪高能的归宿",@"懂财经,拒绝套牢",@"关注体育,不M"];
    switch ([_themeCID integerValue]) {
        case 12:
            _naviBar.title.text = menuName[0];
            break;
        case 4:
            _naviBar.title.text = menuName[1];
            break;
        case 5:
            _naviBar.title.text = menuName[2];
            break;
        case 6:
            _naviBar.title.text = menuName[3];
            break;
        case 8:
            _naviBar.title.text = menuName[4];
            break;
        default:
            break;
    }
}


#pragma mark - UITableViewDelegate & UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.SGThemePageContentArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    SGThemePageModel *model = self.SGThemePageContentArray[indexPath.row];
    if (model.images[0]) {
        SGReaderListWithPictureCell *cell = [tableView dequeueReusableCellWithIdentifier:@"PICCELL" forIndexPath:indexPath];
        [cell configureCellWithModels:model];
        //设置cell选中状态
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }else {
        SGReaderListNoPictureCell *cell = [tableView dequeueReusableCellWithIdentifier:@"NOPICCELL" forIndexPath:indexPath];
        //设置cell选中状态
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        [cell configureCellWithModel:model];
        return cell;
    }
}
//push入详情界面
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    dispatch_async(dispatch_get_global_queue( DISPATCH_QUEUE_PRIORITY_LOW, 0), ^{
        // Do something...
        MBProgressHUD *HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
        [self.navigationController.view addSubview:HUD];
        
        HUD.delegate = self;
        HUD.labelText = @"Loading";
        
        [HUD showWhileExecuting:@selector(myTask) onTarget:self withObject:nil animated:YES];
        dispatch_async(dispatch_get_main_queue(), ^{
            [MBProgressHUD hideHUDForView:self.view animated:YES];
        });
    });
    SGThemePageModel *model = self.SGThemePageContentArray[indexPath.row];
    SGThemeContentViewController *SGThemeContentVC = [[SGThemeContentViewController alloc] init];
    NSString *URL = [NSString stringWithFormat:@"%@%@%@",kBaseReaderURL,kContentURL,model.themeID];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager GET:URL parameters:nil success:^(AFHTTPRequestOperation * operation, id responseObject) {
        SGThemeContentVC.SGThemeShare = [responseObject objectForKey:@"share_url"];
        [self.navigationController pushViewController: SGThemeContentVC animated:YES];
    } failure:^(AFHTTPRequestOperation * operation, NSError * error) {
        DLog(@"%@",error);
    }];
}
- (void)myTask {
    // Do something usefull in here instead of sleeping ...
    sleep(2);
}

#pragma mark - 下拉刷新,上拉加载
//上拉加载
- (void)refreshFooter {
    // 添加默认的上拉刷新
    // 设置回调（一旦进入刷新状态，就调用target的action，也就是调用self的loadMoreData方法）
    MJRefreshAutoNormalFooter *footer = [MJRefreshAutoNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(parseMoreData)];
    
    // 设置文字
    [footer setTitle:@"Click or drag up to refresh" forState:MJRefreshStateIdle];
    [footer setTitle:@"Loading more ..." forState:MJRefreshStateRefreshing];
    [footer setTitle:@"No more data" forState:MJRefreshStateNoMoreData];
    
    // 设置字体
    footer.stateLabel.font = [UIFont systemFontOfSize:17];
    
    // 设置颜色
    footer.stateLabel.textColor = [UIColor blueColor];
    
    // 设置footer
    self.SGThemePageView.footer = footer;
}


- (void)parseMoreData {
    if (self.SGThemePageContentArray.count >= 20) {
    NSString *themefURL = [NSString stringWithFormat:@"%@%@%@/%@%@",kBaseReaderURL,kThemeListURL,_themeCID,kBeforeURL,[self setID]];
    [self acquireServerDataWithURL:themefURL];
    }
}

- (NSString *)setID {
    //获取第20个文章的id
    NSString *tID = [self.SGThemePageContentArray[19 + (_page - 1) * 20 - 1] valueForKey:@"themeID"];
    DLog(@"%@",tID);
    _page++;
    DLog(@"%ld",(long)_page);
    //回调上拉加载的方法
    [self refreshFooter];
    return tID;
}

- (void)acquireServerDataWithURL:(NSString *)URL {
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager GET:URL parameters:nil success:^(AFHTTPRequestOperation * operation, id responseObject) {
        //将数据写入缓存
        [self writeToFileWithThemeData:responseObject];
        NSArray *dataArray = [responseObject objectForKey:@"stories"];
        for (NSMutableDictionary *dict in dataArray) {
            SGThemePageModel *model = [[SGThemePageModel alloc] init];
            [model setValuesForKeysWithDictionary:dict];
            [self.SGThemePageContentArray addObject:model];
        }
        [self.SGThemePageView reloadData];
    } failure:^(AFHTTPRequestOperation * operation, NSError * error) {
        DLog(@"%@",error);
    }];
}

//将数据写入缓存
- (void)writeToFileWithThemeData:(id)data
{
    //获取缓存路径
    NSArray *cachesPaths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *path = [cachesPaths objectAtIndex:0];
    //创建文件名
    NSString *fileName = [path stringByAppendingString:@"SGThemePageViewContent.json"];
    NSError *error= nil;
    //将请求的字符串写入缓存
    NSData *bdData = (NSData *)data;
    [bdData writeToFile:fileName atomically:YES];
    if (error) {
        DLog(@"******%@*******",[error localizedDescription]);
    }
    else
    {
        DLog(@"写入成功");
    }
}

#pragma mark - customNavigationBarDelegate
- (void)clickedBackButton:(UIButton *)backButton {
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
