//
//  SGNaviViewController.m
//  ShiGuangNews
//
//  Created by Davin on 15/10/15.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import "SGNaviViewController.h"

@interface SGNaviViewController ()

@end

@implementation SGNaviViewController

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.naviBar = [[SGNavigationBar alloc] initWithFrame:CGRectMake(0, 0,SCREEN_WIDTH, NAVIGATION_BAR_HEIGHT)];
        _naviBar.backgroundImage.image = [UIImage imageNamed:@"navigation_bar_top.9"];
        [self.view addSubview:_naviBar];
    }
    return self;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
