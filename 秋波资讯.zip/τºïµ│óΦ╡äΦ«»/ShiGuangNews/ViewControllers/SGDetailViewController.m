//
//  SGDetailViewController.m
//  ShiGuangNews
//
//  Created by Davin on 15/10/15.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import "SGDetailViewController.h"

@interface SGDetailViewController ()<UIWebViewDelegate>

@property(strong, nonatomic) UIActivityIndicatorView *activityView;//活动指示器
@end

@implementation SGDetailViewController

- (UIActivityIndicatorView *)activityView
{
    if (!_activityView) {
        self.activityView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
        _activityView.center = self.view.center;
        _activityView.color = [UIColor grayColor];
        _activityView.hidesWhenStopped = YES;
        [self.view addSubview:_activityView];
    }
    return _activityView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    [self.naviBar.backButton addTarget:self action:@selector(handleBackBt:) forControlEvents:UIControlEventTouchUpInside];
    self.naviBar.title.text = @"新闻";
}

- (void)viewWillAppear:(BOOL)animated
{
    UIWebView *newsWeb = [[UIWebView alloc] initWithFrame:CGRectMake(0, NAVIGATION_BAR_HEIGHT, SCREEN_WIDTH, SCREEN_HEIGHT - NAVIGATION_BAR_HEIGHT)];
    [newsWeb loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:self.detailURL]]];
    newsWeb.delegate = self;
    [self.view addSubview:newsWeb];
}

- (void)webViewDidStartLoad:(UIWebView *)webView
{
    [self.activityView startAnimating];
}

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [self.activityView stopAnimating];
}
- (void)handleBackBt:(UIButton *)sender
{
    [self.navigationController popToRootViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
