//
//  SGNewsTypeCell.m
//  ShiGuangNews
//
//  Created by Davin on 15/10/15.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import "SGNewsTitleCell.h"

@implementation SGNewsTitleCell

- (UILabel *)title
{
    if (!_title) {
        self.title = [[UILabel alloc] initWithFrame:self.bounds];
        _title.backgroundColor = [UIColor whiteColor];
        _title.font = [UIFont systemFontOfSize:20];
        _title.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:_title];
    }
    return _title;
}
@end
