//
//  NewsViewController.m
//  ShiGuangNews
//
//  Created by Davin on 15/10/15.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import "SGNewsViewController.h"
#import "SGNavigationBar.h"
#import "SGNewsListViewController.h"
#import "SGAttentionViewController.h"
#import "SGNewsTypeModel.h"

@interface SGNewsViewController ()<UIScrollViewDelegate,SGNavigationBarDelegate, SGNBViewControllerDelegate>

@property (strong, nonatomic) UIScrollView *scrollView;//横向滑动视图
@property(strong, nonatomic) NSMutableArray *newsModels;//已选择新闻
@property(strong, nonatomic) NSMutableArray *allModels;//所有新闻;
@property(assign, nonatomic) NSInteger currentPage;//当前页面
@property(strong, nonatomic) NSMutableSet *tableViewSet;//表视图池
- (UIViewController *)viewControllerWithIndex:(NSInteger)index;//通过下标获取视图控制器
@end

@implementation SGNewsViewController

#pragma  mark - 懒加载

-(UIScrollView *)scrollView
{
    if (!_scrollView) {
        self.scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, NAVIGATION_BAR_HEIGHT, SCREEN_WIDTH, SCREEN_HEIGHT - NAVIGATION_BAR_HEIGHT - TABBAR_HEIGHT)];
        _scrollView.bounces = NO;
        _scrollView.showsHorizontalScrollIndicator = NO;
        _scrollView.pagingEnabled = YES;
        _scrollView.delegate = self;
        [self.view insertSubview:_scrollView atIndex:0];
    }
    return _scrollView;
}

- (NSMutableArray *)allModels
{
    if(!_allModels){
        self.allModels = [NSMutableArray array];
    }
    return _allModels;
}

- (NSMutableArray *)newsModels
{
    if (!_newsModels) {
        self.newsModels =[NSMutableArray array];
    }
    return _newsModels;
}

- (NSMutableSet *)tableViewSet
{
    if (!_tableViewSet) {
        self.tableViewSet = [NSMutableSet set];
        for (int i = 0; i < self.newsModels.count; i++) {
            SGNewsListViewController *firstVC = [[SGNewsListViewController alloc] init];
            [_tableViewSet addObject:firstVC];
        }
    }
    return _tableViewSet;
}

- (instancetype)init
{
   self = [super init];
    if (self) {
        self.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"新闻" image:[[UIImage imageNamed:@"news_normal_icon"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] selectedImage:[[UIImage imageNamed:@"news_press_icon"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
        [self.tabBarItem setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:13]} forState:UIControlStateNormal];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if (![defaults objectForKey:@"newsModels"]) {
        NSString *path = [[NSBundle mainBundle] pathForResource:@"NewsTypeList" ofType:@"plist"];
        NSMutableArray *newsArray = [NSMutableArray arrayWithContentsOfFile:path];
        for (int i = 0; i < newsArray.count; i++) {
            NSDictionary *dict = newsArray[i];
            SGNewsTypeModel *model = [[SGNewsTypeModel alloc] init];
            model.title = dict.allKeys[0];
            model.type = dict[model.title];
            if (i < 5) {
                [self.newsModels addObject:model];
            }else
            {
                [self.allModels addObject:model];
            }
        }
        NSData *newsData = [NSKeyedArchiver archivedDataWithRootObject:self.newsModels];
        NSData *allData = [NSKeyedArchiver archivedDataWithRootObject:self.allModels];
        [defaults setObject:newsData forKey:@"newsModels"];
        [defaults setObject:allData forKey:@"allModels"];
    }else
    {
        self.allModels = [NSKeyedUnarchiver unarchiveObjectWithData:[defaults objectForKey:@"allModels"]];
        self.newsModels = [NSKeyedUnarchiver unarchiveObjectWithData:[defaults objectForKey:@"newsModels"]];
    }
    [self configureNavigationBar];
    [self creatNewsList];
    
}

- (void)creatNewsList
{
    self.scrollView.contentSize = CGSizeMake(SCREEN_WIDTH * self.newsModels.count, SCREEN_HEIGHT - NAVIGATION_BAR_HEIGHT - TABBAR_HEIGHT);
    for (int i = 0; i < self.newsModels.count; i++) {
        SGNewsListViewController *firstVC = [[SGNewsListViewController alloc] init];
        firstVC.view.frame = CGRectMake(SCREEN_WIDTH * i, 0, SCREEN_WIDTH, SCREEN_HEIGHT - NAVIGATION_BAR_HEIGHT - TABBAR_HEIGHT);
        firstVC.newsDelegate =self;
        firstVC.index = i;
        [self addChildViewController:firstVC];
        [self.scrollView addSubview:firstVC.view];
        [firstVC refreshPage];
    }
    self.currentPage = 0;
}

- (NSString *)configureDatasource:(SGNBViewController *)viewController
{
    SGNewsTypeModel *model = self.newsModels[viewController.index];
    return model.type;
}

#pragma mark - 创建导航条

- (void)configureNavigationBar
{
    self.naviBar.backgroundImage.image = [UIImage imageNamed:@"navigation_bar_top.9"];
    [self addNaviBarLeftButton];
    [self addNaviBarRightButton];
    [self addNaviBarScrollTitle];
    self.naviBar.delegate = self;
    
}

- (void)addNaviBarLeftButton
{
    
    [self.naviBar.leftButton setImage:[UIImage imageNamed:@"setting_head_icon"] forState:UIControlStateNormal];
    [self.naviBar.leftButton setImageEdgeInsets:UIEdgeInsetsMake(10, 10, 10, 10)];
    [self.naviBar.leftButton addTarget:self action:@selector(handleLeftBt:) forControlEvents:UIControlEventTouchUpInside];
    
}

- (void)addNaviBarRightButton
{
    [self.naviBar.rightButton setImage:[UIImage imageNamed:@"add_button_normal"] forState:UIControlStateNormal];
    [self.naviBar.rightButton setImageEdgeInsets:UIEdgeInsetsMake(10, 10, 10, 10)];
    [self.naviBar.rightButton addTarget:self action:@selector(handleRightBt:) forControlEvents:UIControlEventTouchUpInside];
}

- (void)addNaviBarScrollTitle
{
     [self.naviBar setScrollTitleWithTitleArray:self.newsModels];
}

#pragma mark - 点击导航栏按钮

- (void)handleLeftBt:(UIButton *)sender
{
    [self.delegate showLoginView];
}

- (void)handleRightBt:(UIButton *)sender
{
    SGAttentionViewController *attentionVC = [[SGAttentionViewController alloc] init];
    attentionVC.passNews = ^(NSMutableArray *newsModels,NSMutableArray *allNews)
    {
        self.newsModels = newsModels;
        self.allModels = allNews;
        [self.naviBar.scrollTitle removeFromSuperview];
        [self addNaviBarScrollTitle];
        for (SGNewsListViewController *newsVC in [self childViewControllers]) {
            [newsVC removeFromParentViewController];
            [newsVC.view removeFromSuperview];
        }
        [self creatNewsList];
        self.scrollView.contentOffset = CGPointMake(0, 0);
        dispatch_queue_t serialQueue = dispatch_queue_create("com.doule3g.GCD.mySerialQueue", DISPATCH_QUEUE_SERIAL);
        dispatch_async(serialQueue, ^{
            NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
            NSData *all = [NSKeyedArchiver archivedDataWithRootObject:allNews];
            NSData *news = [NSKeyedArchiver archivedDataWithRootObject:newsModels];
            [defaults setObject:all forKey:@"allModels"];
            [defaults setObject:news forKey:@"newsModels"];
        });
    };
    attentionVC.datasource = self.newsModels;
    attentionVC.allTitle = self.allModels;
    [self.navigationController pushViewController:attentionVC animated:YES];
}

#pragma mark - 根据下标获取视图控制器

- (UIViewController *)viewControllerWithIndex:(NSInteger)index
{
    for (SGNewsListViewController *newsVC in [self childViewControllers]) {
        if (newsVC.index == index) {
            return newsVC;
        }
    }
    return nil;
}

#pragma mark - 切换新闻页

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    NSInteger page = scrollView.contentOffset.x /SCREEN_WIDTH;
    self.currentPage = page;
    self.naviBar.currentIndex = page;
    [self.naviBar refreshNewsPage];
}

- (void)replaceNewsPage:(NSInteger)page
{
    self.currentPage = page;
    self.scrollView.contentOffset = CGPointMake(SCREEN_WIDTH * page, 0);
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
