//
//  MainViewController.m
//  ShiGuangNews
//
//  Created by Davin on 15/10/15.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import "SGMainViewController.h"
#import "SGLoginViewController.h"
#import "SGNewsViewController.h"
#import "SGMainTabBarController.h"
#import "SGMenuViewController.h"
#import "SGMainTabBarInstance.h"

@interface SGMainViewController ()<SGNewsViewControllerDelegate>

@property(strong, nonatomic) SGLoginViewController *loginVC;
@property(strong, nonatomic) SGMainTabBarController *contentTabVC;
@property(strong, nonatomic) UIView *coverView;//显示登录界面时添加,防止误触

@end

@implementation SGMainViewController

#pragma mark - 懒加载

- (SGLoginViewController *)loginVC
{
    if (!_loginVC) {
        self.loginVC = [[SGLoginViewController alloc] init];
        [self addChildViewController:_loginVC];
    }
    return _loginVC;
}

- (UIView *)coverView
{
    if (!_coverView) {
        self.coverView = [[UIView alloc] initWithFrame:self.contentTabVC.view.bounds];
    }
    return _coverView;
}


- (SGMainTabBarController *)contentTabVC
{
    if (!_contentTabVC) {
        self.contentTabVC = [[SGMainTabBarController alloc] init];
        self.contentTabVC = [SGMainTabBarInstance sharedInstance];
        NSArray *viewControllers = [self creatViewControllers];
        _contentTabVC.viewControllers = viewControllers;
        [self addChildViewController:_contentTabVC];
    }
    return _contentTabVC;
}

#pragma mark - 创建标签控制器管理的视图控制器

- (NSArray *)creatViewControllers
{
    SGNewsViewController *newsVC = [[SGNewsViewController alloc] init];
    SGMenuViewController *readVC = [[SGMenuViewController alloc] init];
    NSArray *viewControllers = @[newsVC,readVC];
    return viewControllers;
}


- (void)viewDidLoad {
    [super viewDidLoad];
//     Do any additional setup after loading the view.
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.navigationController.navigationBarHidden = YES;
    UIView *contentView = self.contentTabVC.view;
    contentView.backgroundColor = [UIColor whiteColor];
    contentView.layer.shadowColor = [UIColor lightGrayColor].CGColor;
    contentView.layer.shadowOffset = CGSizeMake(- 3, 0);
    contentView.layer.shadowOpacity = 0.8;
    SGNewsViewController *newsVC = (SGNewsViewController *)self.contentTabVC.viewControllers[0];
    newsVC.delegate = self;
    [self.view addSubview:contentView];
}

#pragma mark - ContentViewController代理方法


- (void)showLoginView
{
    [self.view insertSubview:self.loginVC.view atIndex:0];
    [self addTapGestureRecognizer];
    [self addPanGestureRecognizer];
    CGRect frame = self.contentTabVC.view.frame;
    frame.origin.x = CGRectGetWidth(self.view.bounds) * 0.7;
    [UIView animateWithDuration:0.5 animations:^{
        self.contentTabVC.view.frame = frame;
    }];
}

#pragma mark - 切换两个界面的动画

- (void)addTapGestureRecognizer
{
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTap:)];
    [self.coverView addGestureRecognizer:tap];
    [self.contentTabVC.view addSubview:self.coverView];
}

- (void)addPanGestureRecognizer
{
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePan:)];
    [self.coverView addGestureRecognizer:pan];
}

- (void)handleTap:(UITapGestureRecognizer *)sender
{
    CGRect frame = self.contentTabVC.view.frame;
    frame.origin.x = 0;
    [UIView animateWithDuration:0.5 animations:^{
        self.contentTabVC.view.frame = frame;
    } completion:^(BOOL finished) {
        [self.loginVC.view removeFromSuperview];
        self.loginVC = nil;
    }];
    [sender.view removeFromSuperview];
}

- (void)handlePan:(UIPanGestureRecognizer *)sender
{
    CGPoint CurrentPoint = [sender translationInView:self.view];
    self.contentTabVC.view.transform = CGAffineTransformTranslate(self.contentTabVC.view.transform, CurrentPoint.x, 0);
    [sender setTranslation:CGPointZero inView:self.view];
    if (sender.state == UIGestureRecognizerStateEnded && self.contentTabVC.view.frame.origin.x > 120) {
        CGRect frame = self.contentTabVC.view.frame;
        frame.origin.x = CGRectGetWidth(self.view.bounds) * 0.7;
        [UIView animateWithDuration:0.35 animations:^{
            self.contentTabVC.view.frame = frame;
        }];
        
    }else if(sender.state == UIGestureRecognizerStateEnded && self.contentTabVC.view.frame.origin.x < 120)
    {
        CGRect frame = self.contentTabVC.view.frame;
        frame.origin.x = 0;
        [UIView animateWithDuration:0.35 animations:^{
            self.contentTabVC.view.frame = frame;
        } completion:^(BOOL finished) {
            [self.loginVC.view removeFromSuperview];
            self.loginVC = nil;
        }];
        [sender setTranslation:CGPointZero inView:self.view];
        [sender.view removeFromSuperview];
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
