//
//  SecondViewController.h
//  ShiGuangNews
//
//  Created by Davin on 15/10/15.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import "SGNBViewController.h"

typedef void (^datasourct)(void);
@interface SGSecondViewController : SGNBViewController
@property(copy, nonatomic) datasourct data;
@end
