//
//  SGBaseViewController.h
//  ShiGuangNews
//
//  Created by Davin on 15/10/15.
//  Copyright (c) 2015年 逗乐科技. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SGNormalCell.h"
#import "SGSingleImageCell.h"
#import "SGMultipleImageCell.h"

@class SGNBViewController;
@protocol SGNBViewControllerDelegate <NSObject>

- (NSString *)configureDatasource:(SGNBViewController *)viewController;

@end

@interface SGNBViewController : UIViewController

@property(assign, nonatomic) NSInteger index;//视图的下标;
@property(weak, nonatomic) id<SGNBViewControllerDelegate> newsDelegate;//代理

- (void)refreshPage;//手动刷新界面;
@end
